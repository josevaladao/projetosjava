create database lojavirtual;

use lojavirtual;

create table categoria (
   idCategoria int not null primary key auto_increment,
   nomeCategoria varchar(15)
);

insert into categoria values(null,'Livros');
insert into categoria values(null,'Informatica');
insert into categoria values(null,'Eletronicos');
insert into categoria values(null,'Roupas');
insert into categoria values(null,'DVD');

create table produto(
idProduto int primary key auto_increment,
nome varchar(20) not null,
qtdEstoque int not null,
preco double(10,2) not null,
validade date not null,
idCategoria int not null,
foreign key(idCategoria) references categoria(idCategoria)
);
