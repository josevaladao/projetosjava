package br.com.lojavirtual1.persistencia;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.lojavirtual1.entidade.Categoria;
import br.com.lojavirtual1.entidade.Produto;

public class ProdutoDao extends Dao {
	
	public void cadastrarProduto(Produto produto) throws SQLException{
		open();
		String sql = "INSERT INTO produto(nome,qtdEstoque,preco,validade,idCategoria)VALUES(?,?,?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, produto.getNome());
		stmt.setInt(2, produto.getQtdEstoque());
		stmt.setDouble(3, produto.getPreco());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, sdf.format(produto.getValidade()));
		stmt.setInt(5, produto.getCategoria().getIdCategoria());
		stmt.execute();
		close();
	}
	public void atualizarProduto(Produto produto) throws SQLException{
		open();
		String sql = "UPDATE produto SET nome= ?, qtdEstoque= ?,preco = ?,"
				+ "validade = ? WHERE idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, produto.getNome());
		stmt.setInt(2, produto.getQtdEstoque());
		stmt.setDouble(3, produto.getPreco());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, sdf.format(produto.getValidade()));
		//stmt.setInt(5, produto.getCategoria().getIdCategoria());
		stmt.setInt(5, produto.getIdProduto());
		stmt.execute();
		close();
	}
	public void excluirProduto(int idProduto) throws SQLException{
		open();
		String sql = "DELETE FROM produto WHERE idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idProduto);
		stmt.execute();
		close();
	}
	public Produto buscarProdutoPorId(int idProduto) throws SQLException{
		open();
		String sql = "SELECT * FROM produto WHERE idProduto = ?";
		
		stmt = con.prepareStatement(sql);
		
		stmt.setInt(1, idProduto);
		
		Produto produto = null;
		rs = stmt.executeQuery();
		
		if(rs.next()){
			produto  = new Produto(rs.getInt("idProduto"), rs.getString("nome"),
					rs.getInt("qtdEstoque"), rs.getDouble("preco"), rs.getDate("validade"));
			
		}
		close();
		return produto;
	}
	
	public List<Produto> buscarProduto(String nome) throws SQLException{
		open();
		//String sql = "SELECT * FROM produto INNER JOIN categoria ON produto.idCategoria = categoria.idCategoria WHERE nome LIKE ?";
		String sql = "SELECT * FROM produto, categoria WHERE produto.idCategoria = categoria.idCategoria  AND nome LIKE ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, nome + "%");
		
		rs = stmt.executeQuery();
		
		List<Produto> lista = new ArrayList<Produto>();
		
		while(rs.next()){
			Produto produto = new Produto(rs.getInt("idProduto"), rs.getString("nome"),rs.getInt("qtdEstoque"),
					rs.getDouble("preco"),rs.getDate("validade"));
			
						
			Categoria categoria = new Categoria(rs.getInt("idCategoria"), rs.getString("nomeCategoria"));
			
			produto.setCategoria(categoria);
			lista.add(produto);
			
		}
		close();
		return lista;
	}
	
	
	
	
	
	
	
}
