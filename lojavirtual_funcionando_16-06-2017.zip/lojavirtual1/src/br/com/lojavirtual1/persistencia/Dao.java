package br.com.lojavirtual1.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class Dao {
	protected Connection con;
	protected PreparedStatement stmt;
	protected ResultSet rs;

	private final String URL = "jdbc:mysql://localhost/lojavirtual";
	private final String USER = "root";
	private final String PASS = "";

	protected void open() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASS);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	protected void close() throws SQLException{
		if(con != null){
			con.close();
		}
		if(stmt != null){
			stmt.close();
		}
		if(rs != null){
			rs.close();
		}
	}
	public static void main(String[] args) {
		try {
			Dao d = new Dao();
			d.open();
			d.close();
			System.out.println("Conectado....");
		} catch (Exception e) {
			System.out.println("Deu Ruim....");
			e.printStackTrace();
		}
		
		
	}
		
	
	
}
