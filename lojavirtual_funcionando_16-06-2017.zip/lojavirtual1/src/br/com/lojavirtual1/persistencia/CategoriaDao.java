package br.com.lojavirtual1.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.lojavirtual1.entidade.Categoria;

public class CategoriaDao extends Dao {
	
	public List<Categoria> listarCategoria() throws SQLException{
		//Abrindo uma cenx�o
		open();
		//preparando a consulta
		String sql = "SELECT * FROM categoria";
		stmt = con.prepareStatement(sql);
		List<Categoria> lista = new ArrayList<Categoria>();
		//Executando a Query SELECt
		rs = stmt.executeQuery();
		//Enquanto existir linhas de registro o rs verifica
		while(rs.next()){
			//Criando um objeto do tipo Categoria
			Categoria cat = new Categoria();
			cat.setIdCategoria(rs.getInt("idCategoria"));
			cat.setNomeCategoria(rs.getString("nomeCategoria"));
			//Adiciono a categoria � lista
			lista.add(cat);
		}
		//Fechando uma conex�o
		close();
		//Retornando a lista
		return lista;
	}
}
