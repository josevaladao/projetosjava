package br.com.lojavirtual1.manager;

import java.util.List;

import br.com.lojavirtual1.entidade.Categoria;
import br.com.lojavirtual1.persistencia.CategoriaDao;

public class CategoriaBean {
	
	private List<Categoria> listaCategoria;
	
	public CategoriaBean() {
		//No construtor vamos carregar a lista com os dados do banco
		try {
			listaCategoria = new CategoriaDao().listarCategoria();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}
	
}
