package br.com.lojavirtual1.controle;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual1.entidade.Categoria;
import br.com.lojavirtual1.entidade.Produto;
import br.com.lojavirtual1.persistencia.ProdutoDao;

@WebServlet({ "/ControleProduto", "/cadastrar.html", "/buscar.html", "/editar.html","/excluir.html","/confirmacaoProduto.html"})
public class ControleProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleProduto() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		try {
			//Pegar a URL que chamou essa servlet
			String url = request.getServletPath();
			if(url.equalsIgnoreCase("/cadastrar.html")){
				cadastrar(request, response);
			}else if(url.equalsIgnoreCase("/buscar.html")){
				buscar(request,response);
			}else if(url.equalsIgnoreCase("/editar.html")){
				editar(request, response);
			}else if(url.equalsIgnoreCase("/excluir.html")){				
				excluir(request, response);
			}else if(url.equalsIgnoreCase("/confirmacaoProduto.html")){
				confirmacaoProduto(request, response);
			}else{
				throw new Exception("URL Invalida!");
			}
		} catch (Exception e) {
			response.sendRedirect("buscarProduto.jsp");
		}
	}

	protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Pegando os dados do formul�rio
		try {
			String nome = request.getParameter("nome");
			String qtdEstoque = request.getParameter("qtdEstoque");
			String preco = request.getParameter("preco");
			String idCategoria = request.getParameter("categoria");
			String validade = request.getParameter("validade");

			// Setando os dados pelo m�todo set da classe Produto
			Produto produto = new Produto();
			Categoria categoria = new Categoria();

			produto.setNome(nome);
			produto.setQtdEstoque(new Integer(qtdEstoque));
			produto.setPreco(new Double(preco));
			categoria.setIdCategoria(new Integer(idCategoria));
			// Relacionando as Classes Produto com Categoria
			produto.setCategoria(categoria);
			produto.setValidade(produto.converterData(validade));

			// Gravar os dados no banco..... chamar o produtoDao e o m�todo
			// cadastrarProduto...

			ProdutoDao pd = new ProdutoDao();
			pd.cadastrarProduto(produto);

			request.setAttribute("msg", "<div class='alert alert-success'>Produto cadastrado!</div>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o cadastrado!</div>");
		} finally {
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	protected void buscar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String nome = request.getParameter("nome");
			ProdutoDao dao = new ProdutoDao();
			List<Produto> lista = dao.buscarProduto(nome);

			if (lista.size() == 0) {
				request.setAttribute("msg",
						"<div class='alert alert-info'>Nenhum cliente encontrado, tente novamente!</div>");
			} else {
				request.setAttribute("nome", nome);
				request.setAttribute("lista", lista);
				request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void editar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Integer idProduto = new Integer(request.getParameter("idProduto"));

			Produto produto = new ProdutoDao().buscarProdutoPorId(idProduto);

			if (produto == null) {
				request.setAttribute("msg", "<div class='alert alert-info'>Produto n�o encontrado</div>");
				request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
			} else {
				request.setAttribute("prod", produto);
				request.getRequestDispatcher("editarProduto.jsp").forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: " + e.getMessage() + "</div>");
		}

	}
	protected void excluir(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Integer idProduto = new Integer(request.getParameter("idProduto"));
			
			ProdutoDao dao = new ProdutoDao();
			dao.excluirProduto(idProduto);
			
			request.setAttribute("msg", "<div class='alert alert-success'>" + "Produto excluido com sucesso! </div>");
			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>" + "Produto n�o exclu�do! </div>");
		}finally {
			request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
		}
	}

	protected void confirmacaoProduto(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			String nome = request.getParameter("nome");
			String qtdEstoque = request.getParameter("qtdEstoque");
			String preco = request.getParameter("preco");
			//String idCategoria = request.getParameter("categoria");
			String validade = request.getParameter("validade");
			Integer idProduto = new Integer(request.getParameter("idProduto"));

			// Setando os dados pelo m�todo set da classe Produto
			Produto produto = new Produto();
			//Categoria categoria = new Categoria();
			

			produto.setNome(nome);
			produto.setQtdEstoque(new Integer(qtdEstoque));
			produto.setPreco(new Double(preco));
			//categoria.setIdCategoria(new Integer(idCategoria));
			// Relacionando as Classes Produto com Categoria
			//produto.setCategoria(categoria);
			produto.setValidade(produto.converterData(validade));
			produto.setIdProduto(idProduto);

			// Gravar os dados no banco..... chamar o produtoDao e o m�todo
			// cadastrarProduto...

			ProdutoDao pd = new ProdutoDao();
			pd.atualizarProduto(produto);

			request.setAttribute("msg", "<div class='alert alert-success'>Produto Atualizado!</div>");

		} catch (

		Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o Atualizado!</div>");
		} finally {
			request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
		}

	}

}
