package br.com.lojavirtual1.entidade;

import java.util.Date;
import java.util.GregorianCalendar;

public class Produto {
	private Integer idProduto;
	private String nome;
	private Integer qtdEstoque;
	private Double preco;
	private Date validade;
	// Todo produto tem uma Categoria
	private Categoria categoria;

	public Produto() {

	}
	//Argumentos do construtor sem categoria
	public Produto(Integer idProduto, String nome, Integer qdtEstoque, Double preco, Date validade) {
		this.idProduto = idProduto;
		this.nome = nome;
		this.qtdEstoque = qdtEstoque;
		this.preco = preco;
		this.validade = validade;
	}
	

	@Override
	public String toString() {
		return "Produto [idProduto=" + idProduto + ", nome=" + nome + ", qtdEstoque=" + qtdEstoque + ", preco=" + preco
				+ ", validade=" + validade + ", categoria=" + categoria + "]";
	}
	
	public Integer getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(Integer idProduto) {
		this.idProduto = idProduto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getQtdEstoque() {
		return qtdEstoque;
	}

	public void setQtdEstoque(Integer qtdEstoque) {
		this.qtdEstoque = qtdEstoque;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public Date getValidade() {
		return validade;
	}

	public void setValidade(Date validade) {
		this.validade = validade;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
	public static Date converterData(String data){
		String[] novaData = data.split("/");
		GregorianCalendar cal = new GregorianCalendar(
				new Integer(novaData[2]), 
				new Integer(novaData[1])-1,
				new Integer(novaData[0]));
		return cal.getTime();
	}
	
	
}
