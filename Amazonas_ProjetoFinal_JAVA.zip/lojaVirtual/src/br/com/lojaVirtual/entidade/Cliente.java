package br.com.lojaVirtual.entidade;

public class Cliente {
	private Integer idCliente;
	private String nomeCliente;
	private String email; 
	private String senha;
	private String rg;
	private String cpf;
	private String cep;
	private String cidade;
	private String bairro;
	private String logradouro;
	
	

	
	
	
	public Cliente(){
		
	}






	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", nomeCliente=" + nomeCliente + ", email=" + email + ", senha="
				+ senha + ", rg=" + rg + ", cpf=" + cpf + ", cep=" + cep + ", cidade=" + cidade + ", bairro=" + bairro
				+ ", logradouro=" + logradouro + "]";
	}






	public Integer getIdCliente() {
		return idCliente;
	}






	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}






	public String getNomeCliente() {
		return nomeCliente;
	}






	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}






	public String getEmail() {
		return email;
	}






	public void setEmail(String email) {
		this.email = email;
	}






	public String getSenha() {
		return senha;
	}






	public void setSenha(String senha) {
		this.senha = senha;
	}






	public String getRg() {
		return rg;
	}






	public void setRg(String rg) {
		this.rg = rg;
	}






	public String getCpf() {
		return cpf;
	}






	public void setCpf(String cpf) {
		this.cpf = cpf;
	}






	public String getCep() {
		return cep;
	}






	public void setCep(String cep) {
		this.cep = cep;
	}






	public String getCidade() {
		return cidade;
	}






	public void setCidade(String cidade) {
		this.cidade = cidade;
	}






	public String getBairro() {
		return bairro;
	}






	public void setBairro(String bairro) {
		this.bairro = bairro;
	}






	public String getLogradouro() {
		return logradouro;
	}






	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}






	public Cliente(Integer idCliente, String nomeCliente, String email, String senha, String rg, String cpf, String cep,
			String cidade, String bairro, String logradouro) {
		super();
		this.idCliente = idCliente;
		this.nomeCliente = nomeCliente;
		this.email = email;
		this.senha = senha;
		this.rg = rg;
		this.cpf = cpf;
		this.cep = cep;
		this.cidade = cidade;
		this.bairro = bairro;
		this.logradouro = logradouro;
	}




}
