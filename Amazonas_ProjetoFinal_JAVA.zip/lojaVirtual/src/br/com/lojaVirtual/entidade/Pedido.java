package br.com.lojaVirtual.entidade;

import java.sql.Timestamp;

public class Pedido {
	
	private int codPedido;
	private String email;
	private Timestamp data;
	
	
	public int getCodPedido() {
		return codPedido;
	}
	public void setCodPedido(int codPedido) {
		this.codPedido = codPedido;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Timestamp getData() {
		return data;
	}
	public void setData(Timestamp data) {
		this.data = data;
	}
	
	

}
