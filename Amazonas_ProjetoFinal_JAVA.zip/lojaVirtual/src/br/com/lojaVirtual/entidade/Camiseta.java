package br.com.lojaVirtual.entidade;

public class Camiseta {
	
	private Integer idCamiseta;
	private String nome;
	private String imagem;
	private String descricao;
	private Double preco;
	private String marca;
	private String cor;
	private String genero;
	private Integer quantidadeP;
	private Integer quantidadeM;
	private Integer quantidadeG;
	private Integer quantidadeGG;
	private Integer quantidadeXG;
	
	 public Camiseta() {
	
	}


		public Camiseta(Integer idCamiseta, String nome, String imagem, String descricao, Double preco, String marca,
			String cor, String genero, Integer quantidadeP, Integer quantidadeM, Integer quantidadeG,
			Integer quantidadeGG, Integer quantidadeXG) {
		super();
		this.idCamiseta = idCamiseta;
		this.nome = nome;
		this.imagem = imagem;
		this.descricao = descricao;
		this.preco = preco;
		this.marca = marca;
		this.cor = cor;
		this.genero = genero;
		this.quantidadeP = quantidadeP;
		this.quantidadeM = quantidadeM;
		this.quantidadeG = quantidadeG;
		this.quantidadeGG = quantidadeGG;
		this.quantidadeXG = quantidadeXG;
	}





		public Integer getQuantidadeP() {
			return quantidadeP;
		}
		public void setQuantidadeP(Integer quantidadeP) {
			this.quantidadeP = quantidadeP;
		}
		public Integer getQuantidadeM() {
			return quantidadeM;
		}
		public void setQuantidadeM(Integer quantidadeM) {
			this.quantidadeM = quantidadeM;
		}
		public Integer getQuantidadeG() {
			return quantidadeG;
		}
		public void setQuantidadeG(Integer quantidadeG) {
			this.quantidadeG = quantidadeG;
		}
		public Integer getQuantidadeGG() {
			return quantidadeGG;
		}
		public void setQuantidadeGG(Integer quantidadeGG) {
			this.quantidadeGG = quantidadeGG;
		}
		public Integer getQuantidadeXG() {
			return quantidadeXG;
		}
		public void setQuantidadeXG(Integer quantidadeXG) {
			this.quantidadeXG = quantidadeXG;
		}


	 
	 

	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	public Integer getIdcamiseta() {
		return idCamiseta;
	}
	public void setIdcamiseta(Integer idcamiseta) {
		this.idCamiseta = idcamiseta;
	}
	
	
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	
	
	

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Double getPreco() {
		return preco;
	}
	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public String getImagem() {
		return imagem;
	}
	public void setImagem(String imagem) {
		this.imagem = imagem;
	}


	@Override
	public String toString() {
		return "Camiseta [idCamiseta=" + idCamiseta + ", nome=" + nome + ", imagem=" + imagem + ", descricao="
				+ descricao + ", preco=" + preco + ", marca=" + marca + ", quantidadeP=" + quantidadeP
				+ ", quantidadeM=" + quantidadeM + ", quantidadeG=" + quantidadeG + ", quantidadeGG=" + quantidadeGG
				+ ", quantidadeXG=" + quantidadeXG + ", cor=" + cor + ", genero=" + genero + "]";
	}
	
	
	
	
	
	
	


	 
}