package br.com.lojaVirtual.entidade;

public class Compra {
	
	private Integer idcompra;
	private double precototal;
	private Integer idCliente;
	
	
	public Compra(){
		
	}


	@Override
	public String toString() {
		return "Compra [idcompra=" + idcompra + ", precototal=" + precototal
				+ ", idCliente=" + idCliente + "]";
	}


	public Compra(Integer idcompra, double precototal, Integer idCliente) {
		super();
		this.idcompra = idcompra;
		this.precototal = precototal;
		this.idCliente = idCliente;
	}


	public Integer getIdcompra() {
		return idcompra;
	}


	public void setIdcompra(Integer idcompra) {
		this.idcompra = idcompra;
	}


	public double getPrecototal() {
		return precototal;
	}


	public void setPrecototal(double precototal) {
		this.precototal = precototal;
	}


	public Integer getIdCliente() {
		return idCliente;
	}


	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	
	
	
}
