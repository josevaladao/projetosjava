package br.com.lojaVirtual.entidade;

public class Contato {
	private Integer idMensagem;
	private String nome;
	private String email;
	private String mensagem;
	
	public Contato(){
		
	}
	
	public Integer getIdMensagem() {
		return idMensagem;
	}
	public void setIdMensagem(Integer idMensagem) {
		this.idMensagem = idMensagem;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	@Override
	public String toString() {
		return "Contato [idMensagem=" + idMensagem + ", nome=" + nome
				+ ", email=" + email + ", mensagem=" + mensagem + "]";
	}
	public Contato(Integer idMensagem, String nome, String email,
			String mensagem) {
		super();
		this.idMensagem = idMensagem;
		this.nome = nome;
		this.email = email;
		this.mensagem = mensagem;
	}
	
	
	
}
