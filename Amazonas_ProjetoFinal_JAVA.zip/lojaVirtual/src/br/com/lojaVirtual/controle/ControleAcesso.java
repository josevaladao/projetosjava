package br.com.lojaVirtual.controle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojaVirtual.entidade.Adm;
import br.com.lojaVirtual.entidade.Cliente;
import br.com.lojaVirtual.persistencia.AdmDao;
import br.com.lojaVirtual.persistencia.ClienteDao;
import br.com.lojaVirtual.*;

@WebServlet("/acessocontrol")
public class ControleAcesso extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleAcesso() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String email = request.getParameter("email");
			String senha = request.getParameter("senha");
			String SenhaBD = new ClienteDao().pegaSenha(email);
			
			Cliente u = new ClienteDao().consultarEmailSenha(email, senha);
			Adm a = new AdmDao().consultarEmailSenha(email, senha);

			if (a != null) {
				request.getSession().setAttribute("AdmLogado", a.getNome());
				response.sendRedirect("painel.jsp");
			} else if (u != null) {
				request.getSession().setAttribute("email", email);
				request.getSession().setAttribute("usuarioLogado", u.getNomeCliente());
				response.sendRedirect("index.jsp");

			} else {
				
				response.sendRedirect("index.jsp");
				//request.getRequestDispatcher("inicio.jsp").forward(request, response);
				//request.setAttribute("msg", "<div class='alert alert-danger'>" + "Erro no Login!</div>");
				//request.setAttribute("msg", "Erro no Login!");
				//request.setAttribute("msg", "<script type='text/javascript'>alert('assassasa');</script> ");
				
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msglogin", "Erro:" + e.getMessage());
			response.sendRedirect("index.jsp");
			//request.getRequestDispatcher("inicio.jsp").forward(request, response);
		}
	}

}
