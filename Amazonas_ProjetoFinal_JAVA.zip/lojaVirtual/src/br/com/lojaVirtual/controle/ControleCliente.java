package br.com.lojaVirtual.controle;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojaVirtual.entidade.Cliente;
import br.com.lojaVirtual.persistencia.ClienteDao;



@WebServlet({"/ControleUsuario","/cadastrar.html" ,"/buscarCliente.html" , "/excluircliente.html" , "/editarcliente.html" , "/confirmacaocliente.html"})
public class ControleCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ControleCliente() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		execute(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// pegar a url que chamou este servelet
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/cadastrar.html")) {
				cadastrar(request, response);
			} else

			if (url.equalsIgnoreCase("/buscarCliente.html")) {
				buscarCliente(request, response);
			} else 
			if (url.equalsIgnoreCase("/excluircliente.html")){
				excluirCliente(request , response);
			}else
			if (url.equalsIgnoreCase("/editarcliente.html")){
				editarcliente(request , response);
				
			} else
			if (url.equalsIgnoreCase("/confirmacaocliente.html"))	
				confirmacaocliente(request ,response);
			
			else	{ 

			throw new Exception("URL Invalida!");
			}
	} catch (Exception e){
		response.sendRedirect("index.jsp");
		
	}
}
	protected void cadastrar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			String nomecliente = request.getParameter("nomecliente");
			String email = request.getParameter("email");
			String senha = request.getParameter("senha");
			String rg = request.getParameter("rg");
			String cpf = request.getParameter("cpf");
			String cep = request.getParameter("cep");
			String cidade = request.getParameter("cidade");
			String bairro = request.getParameter("bairro");
			String logradouro = request.getParameter("logradouro");
			
			
			Cliente client = new Cliente();
			
			client.setNomeCliente(nomecliente);
			client.setEmail(email);
			client.setSenha(senha);
			client.setRg(rg);
			client.setCpf(cpf);
			client.setCep(cep);
			client.setCidade(cidade);
			client.setBairro(bairro);
			client.setLogradouro(logradouro);
			
			
		
			
			
			ClienteDao clientDao = new ClienteDao();
			
			clientDao.inserir(client);
			
			request.setAttribute("msg",  "<script>"
					+ "alert('Cliente cadastrado com sucesso!');</script>");
			

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<script>"
					+ "alert('Cliente n�o cadastrado!');</script>");
		}finally{
			response.sendRedirect("index.jsp");
			//request.getRequestDispatcher("index.jsp")
				//.forward(request, response);
		}
	}
	
	protected void buscarCliente(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {
			String nomecliente = request.getParameter("nomecliente");
			ClienteDao clie = new ClienteDao();
			List<Cliente> lista = clie.buscarCliente(nomecliente);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>"
						+ "Nenhum cliente encontrado, tente novamente!</div>");
			}
			request.setAttribute("nomecliente", nomecliente);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscarcliente.jsp").forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected void excluirCliente(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			//pegar o id produto
			Integer id = new Integer(request.getParameter("id")); 
			
			ClienteDao clientedao= new ClienteDao();
			clientedao.excluirCliente(id);
			
			request.setAttribute("msg", "<div class='alert alert-success'>" + "Cliente excluido com sucesso </div>");
			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>" + "Cliente nao excluido</div>");
			
			
		}finally{
			request.getRequestDispatcher("buscarcliente.jsp").forward(request, response);
		}
		
		
	}
	
	protected void editarcliente(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {
		
		Integer id = new Integer(request.getParameter("id"));	
		
		Cliente cliente = new ClienteDao().buscarPorIdcliente(id);
	
		if(cliente == null){
			request.setAttribute("msg", "<div class='alert alert-info'>" + "Cliente nao encontrado</div>");
			request.getRequestDispatcher("buscarcliente.jsp").forward(request, response);
			
			}else{
				request.setAttribute("cli", cliente);
				
				request.getRequestDispatcher("editarcliente.jsp").forward(request, response);;
				
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: " + e.getMessage() + "</div>");
			
		}
	}
	protected void confirmacaocliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			
			String nomecliente = request.getParameter("nomecliente");
			String email = request.getParameter("email");
			String senha = request.getParameter("senha");
			String rg = request.getParameter("rg");
			String cpf = request.getParameter("cpf");
			String cep = request.getParameter("cep");
			String cidade = request.getParameter("cidade");
			String bairro = request.getParameter("bairro");
			String logradouro = request.getParameter("logradouro");
			Integer idcliente = new Integer(request.getParameter("idcliente"));

			Cliente client = new Cliente();
			
			client.setIdCliente(idcliente);
			client.setNomeCliente(nomecliente);
			client.setEmail(email);
			client.setSenha(senha);
			client.setRg(rg);
			client.setCpf(cpf);
			client.setCep(cep);
			client.setCidade(cidade);
			client.setBairro(bairro);
			client.setLogradouro(logradouro);
			
			//Editar no banco
			new ClienteDao().editarcliente(client);
			request.setAttribute("msg", "<div class='alert alert-success'>"
					+ "Cliente editado com sucesso</div>");
			
		}catch(Exception e){
			
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro ao editar</div>");
			
		}finally{
			request.getRequestDispatcher("buscarcliente.jsp").forward(request, response);
		}	
	}
		}





