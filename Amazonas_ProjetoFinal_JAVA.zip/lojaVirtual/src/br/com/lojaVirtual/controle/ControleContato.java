package br.com.lojaVirtual.controle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojaVirtual.entidade.Contato;
import br.com.lojaVirtual.persistencia.ContatoDao;

@WebServlet({"/ControleContato","/contato.html"})
public class ControleContato extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleContato() {
		super();
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		execute(request, response);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		execute(request, response);

	}

	protected void execute(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {

			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/contato.html")) {
				contato(request, response);
			} else {
				throw new Exception("URL Invalida!");
			}
		} catch (Exception e) {
			response.sendRedirect("index.jsp");

		}

	}

	protected void contato(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {

			String nome = request.getParameter("nome");
			String email = request.getParameter("email");
			String mensagem = request.getParameter("mensagem");
			
			
			Contato cont = new Contato();
			
			cont.setNome(nome);
			cont.setEmail(email);
			cont.setMensagem(mensagem);
			
			
			ContatoDao contdao = new ContatoDao();
			
			contdao.contato(cont);
			
			
			request.setAttribute("msg", "<div class='alert alert-success' style='float:left;'>"
					+ "Mensagem enviada com sucesso!</div>");
			

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger' style='float:left;'>"
					+ "Mensagem n�o enviada!</div>");
		}finally{
			response.sendRedirect("contato.jsp");
			//request.getRequestDispatcher("contato.jsp")
				//.forward(request, response);
		}
	}
}
