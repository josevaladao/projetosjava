package br.com.lojaVirtual.controle;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojaVirtual.entidade.Camiseta;
import br.com.lojaVirtual.persistencia.CamisetaDao;

@WebServlet({ "/ControleCamiseta", "/cadastrocamiseta.html", "/buscarCamisetaAdm.html"  ,"/buscarcamiseta.html"  ,"/excluircamiseta.html", "/editarcamiseta.html" , "/confirmacaocamiseta.html"})
public class ControleCamiseta extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleCamiseta() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		execute(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		execute(request, response);
	}

	protected void execute(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			// pegar a url que chamou este servelet
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/cadastrocamiseta.html")) {
				cadastrocamiseta(request, response);
			} else
			if (url.equalsIgnoreCase("/buscarCamisetaAdm.html")) {
				buscarCamisetaAdm(request, response);
			} else 
			if (url.equalsIgnoreCase("/buscarcamiseta.html")) {
				buscarcamiseta(request, response);
			} else 
			if (url.equalsIgnoreCase("/excluircamiseta.html")){
				excluircamiseta(request , response);
			}else
			if (url.equalsIgnoreCase("/editarcamiseta.html")){
				editarcamiseta(request , response);
				
			} else
			if (url.equalsIgnoreCase("/confirmacaocamiseta.html"))	
				confirmacaocamiseta(request ,response);
			
		else	{ 

			throw new Exception("URL Invalida!");
			}
	} catch (Exception e){
		response.sendRedirect("index.jsp");
		
	}
}
		

	protected void cadastrocamiseta(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {

			String nome = request.getParameter("nome");
			String imagem = request.getParameter("imagem");
			String descricao = request.getParameter("descricao");
			String preco = request.getParameter("preco");
			String marca = request.getParameter("marca");
			String cor = request.getParameter("cor");
			String genero = request.getParameter("genero");
			String quantidadeP = request.getParameter("quantidadeP");
			String quantidadeM = request.getParameter("quantidadeM");
			String quantidadeG = request.getParameter("quantidadeG");
			String quantidadeGG = request.getParameter("quantidadeGG");
			String quantidadeXG = request.getParameter("quantidadeXG");

			Camiseta camiseta = new Camiseta();

			Integer valor = 0;
			camiseta.setNome(nome);
			camiseta.setImagem(imagem);
			camiseta.setDescricao(descricao);
			camiseta.setPreco(new Double(preco));
			camiseta.setMarca(marca);
			camiseta.setCor(cor);
			camiseta.setGenero(genero);
			if(quantidadeP.equals("")){
				camiseta.setQuantidadeP(new Integer(valor));
			}else{
				camiseta.setQuantidadeP(new Integer(quantidadeP));
			}
			
			if(quantidadeM.equals("")){
				camiseta.setQuantidadeM(new Integer(valor));
			}else{
				camiseta.setQuantidadeM(new Integer(quantidadeM));
			}
			
			if(quantidadeG.equals("")){
				camiseta.setQuantidadeG(new Integer(valor));
			}else{
				camiseta.setQuantidadeG(new Integer(quantidadeG));
			}
			
			if(quantidadeGG.equals("")){
				camiseta.setQuantidadeGG(new Integer(valor));
			}else{
				camiseta.setQuantidadeGG(new Integer(quantidadeGG));
			}
			
			if(quantidadeXG.equals("")){
				camiseta.setQuantidadeXG(new Integer(valor));
			}else{
				camiseta.setQuantidadeXG(new Integer(quantidadeXG));
			}
			
			
			
			
			
			
			

			CamisetaDao camisetaDao = new CamisetaDao();

			camisetaDao.cadastrar(camiseta);


			request.setAttribute("msg", "<script>"
					+ "alert('Cadastrado com Sucesso');</script>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>"
					+ "Camiseta nao cadastrada!</div>");
		} finally {
			response.sendRedirect("painel.jsp");
			//request.getRequestDispatcher("painel.jsp").forward(request,response);
		}
	}
	
	protected void buscarCamisetaAdm(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {
			String nome = request.getParameter("nome");
			CamisetaDao ct = new CamisetaDao();
			List<Camiseta> lista = ct.buscar(nome);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>"
						+ "Nenhum camiseta encontrada, tente novamente!</div>");
			}
			request.setAttribute("nome", nome);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscarAdm.jsp").forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void buscarcamiseta(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {
			String nome = request.getParameter("nome");
			CamisetaDao ct = new CamisetaDao();
			List<Camiseta> lista = ct.buscar(nome);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>"
						+ "Nenhum camiseta encontrada, tente novamente!</div>");
			}
			request.setAttribute("nome", nome);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscar.jsp").forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	protected void excluircamiseta(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			//pegar o id produto
			Integer id = new Integer(request.getParameter("id")); 
			
			CamisetaDao camisetadao = new CamisetaDao();
			camisetadao.excluirCamiseta(id);
			
			request.setAttribute("msg", "<div class='alert alert-success'>" + "Camiseta excluida com sucesso </div>");
			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>" + "Camiseta  nao excluida</div>");
			
			
		}finally{
			request.getRequestDispatcher("buscarAdm.jsp").forward(request, response);
		}
		
		
	}
	protected void editarcamiseta(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		try {
		//id do produto para editar
		Integer id = new Integer(request.getParameter("id"));	
		//Buscar o produto id
		Camiseta prod = new CamisetaDao().buscarPorId(id);
	
		//se o produto nao existir voltar a buscar
		if(prod == null){
			request.setAttribute("msg", "<div class='alert alert-info'>" + "Produto nao encontrado</div>");
			request.getRequestDispatcher("buscarAdm.jsp").forward(request, response);
			
			}else{
				request.setAttribute("p", prod);
				//Esta pagina (jsp) devia mostra uma formulario preenchido com os do prdouto que sera editado
				request.getRequestDispatcher("editarcamiseta.jsp").forward(request, response);
				
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: " + e.getMessage() + "</div>");
			
		}
	}
		protected void confirmacaocamiseta(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try{
				
				
				String nome = request.getParameter("nome");
				String descricao = request.getParameter("descricao");
				String imagem = request.getParameter("imagem");
				Double preco = new Double(request.getParameter("preco"));
				String marca = request.getParameter("marca");
				Integer idcamiseta = new Integer(request.getParameter("idcamiseta"));
				String cor = request.getParameter("cor");
				String genero = request.getParameter("genero");
				Integer quantidadeP = new Integer(request.getParameter("quantidadeP"));
				Integer quantidadeM = new Integer(request.getParameter("quantidadeM"));
				Integer quantidadeG = new Integer(request.getParameter("quantidadeG"));
				Integer quantidadeGG = new Integer(request.getParameter("quantidadeGG"));
				Integer quantidadeXG = new Integer(request.getParameter("quantidadeXG"));
				

				Camiseta camiseta = new Camiseta();
				
				camiseta.setIdcamiseta(idcamiseta);	
				camiseta.setNome(nome);
				camiseta.setImagem(imagem);
				camiseta.setDescricao(descricao);
				camiseta.setPreco(new Double(preco));
				camiseta.setMarca(marca);
				camiseta.setCor(cor);
				camiseta.setGenero(genero);
				camiseta.setQuantidadeP(new Integer(quantidadeP));
				camiseta.setQuantidadeM(new Integer(quantidadeM));
				camiseta.setQuantidadeG(new Integer(quantidadeG));
				camiseta.setQuantidadeGG(new Integer(quantidadeGG));
				camiseta.setQuantidadeXG(new Integer(quantidadeXG));
				
				
				//Editar no banco
				new CamisetaDao().editarCamiseta(camiseta);
				request.setAttribute("msg", "<div class='alert alert-success'>"
						+ "Produto editado com sucesso</div>");
				
			}catch(Exception e){
				
				e.printStackTrace();
				request.setAttribute("msg", "<div class='alert alert-danger'>Erro ao editar</div>");
				
			}finally{
				request.getRequestDispatcher("buscarAdm.jsp").forward(request, response);
			}	
		}
			}

