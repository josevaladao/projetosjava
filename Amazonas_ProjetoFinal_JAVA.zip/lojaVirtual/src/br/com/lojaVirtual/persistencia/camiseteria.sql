-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 29-Jun-2017 às 19:48
-- Versão do servidor: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `camiseteria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adm`
--

CREATE TABLE IF NOT EXISTS `adm` (
  `idAdm` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(80) NOT NULL,
  PRIMARY KEY (`idAdm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `adm`
--

INSERT INTO `adm` (`idAdm`, `nome`, `email`, `senha`) VALUES
(1, 'Administrador', 'adm@adm.com', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `camiseta`
--

CREATE TABLE IF NOT EXISTS `camiseta` (
  `idCamiseta` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) CHARACTER SET latin1 NOT NULL,
  `imagem` varchar(100) NOT NULL,
  `descricao` varchar(300) NOT NULL,
  `preco` double NOT NULL,
  `marca` varchar(80) CHARACTER SET latin1 NOT NULL,
  `cor` varchar(80) NOT NULL,
  `genero` varchar(9) NOT NULL,
  `quantidadeP` int(200) NOT NULL,
  `quantidadeM` int(200) NOT NULL,
  `quantidadeG` int(200) NOT NULL,
  `quantidadeGG` int(200) NOT NULL,
  `quantidadeXG` int(200) NOT NULL,
  PRIMARY KEY (`idCamiseta`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `camiseta`
--

INSERT INTO `camiseta` (`idCamiseta`, `nome`, `imagem`, `descricao`, `preco`, `marca`, `cor`, `genero`, `quantidadeP`, `quantidadeM`, `quantidadeG`, `quantidadeGG`, `quantidadeXG`) VALUES
(1, 'Total Flex', '01.jpg', '      Camiseta Hurley Manga Curta History Verde, com estampa frontal, mangas curtas e gola careca.\r\nConfeccionada em 100% Algodão.      ', 50, 'DC Comics', 'Verde', 'Masculino', 0, 45, 90, 34, 30),
(2, 'Rock Balboa', '02.jpg', 'Camiseta Hurley Manga Curta History Preto, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 80, 'DC Comics', 'Branca', 'Feminino', 30, 30, 30, 30, 30),
(4, 'Snorlax Pokemon', '03.jpg', 'Camiseta Pokemon Manga Curta Amarelo, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 70, 'asdsa', 'amarelo', 'Masculino', 10, 10, 10, 10, 10),
(5, 'Hacker', '04.jpg', 'Camiseta Hack Manga Curta Marron, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 85, 'asasas', 'Marrom', 'Masculino', 52, 52, 0, 0, 10),
(6, 'Death', '05.jpg', 'Camiseta Death Manga Curta History Preto, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 84.9, 'asasas', 'Preto', 'Feminino', 0, 0, 96, 60, 66),
(7, 'Dark Bunny', '06.jpg', 'Camiseta DarkBunny Manga Curta Cinza, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 104, 'sas', 'Cinza', 'Feminino', 10, 15, 20, 25, 30),
(8, 'Pokemon Academy', '07.jpg', 'Camiseta Pokemon Manga Curta Cinza, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 50, 'lklkl', 'Cinza', 'Feminino', 12, 12, 12, 12, 12),
(9, 'Mário Brother', '08.jpg', 'Camiseta Mário Brother Manga Curta Vermelho, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 85.95, 'sdds', 'Vermelho', 'Feminino', 80, 80, 80, 80, 80),
(10, 'Gamer Boy', '09.jpg', 'Camiseta BoyGamer Manga Curta Cinza, com estampa frontal, mangas curtas e gola careca.\nConfeccionada em 100% Algodão.', 102.34, 'Cinza', 'Cinza', 'Feminino', 65, 56, 28, 50, 10),
(11, 'The Flash', '10.jpg', '  Camiseta The Flash Manga Curta Cinza, com estampa frontal, mangas curtas e gola careca.\r\nConfeccionada em 100% Algodão.  ', 49.9, 'DC Comics', 'Cinza', 'Unissex', 20, 20, 1, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `idcliente` int(11) NOT NULL AUTO_INCREMENT,
  `nomecliente` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(80) NOT NULL,
  `rg` varchar(80) NOT NULL,
  `cpf` varchar(80) NOT NULL,
  `cep` varchar(80) NOT NULL,
  `cidade` varchar(80) NOT NULL,
  `bairro` varchar(80) NOT NULL,
  `logradouro` varchar(80) NOT NULL,
  PRIMARY KEY (`idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idcliente`, `nomecliente`, `email`, `senha`, `rg`, `cpf`, `cep`, `cidade`, `bairro`, `logradouro`) VALUES
(2, 'teste Moura', 'teste@teste.com', '123', '1231', '3321', '7865-89', 'Duque de Caxias', 'Santa Cruz da Serra', 'casa'),
(20, 'Adriano', 'dri@gmail.com', '88', '123456489', '87979898897', '79889798', 'Dritópolis', 'Dritopólio', 'Driu');

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

CREATE TABLE IF NOT EXISTS `compra` (
  `idcompra` int(11) NOT NULL AUTO_INCREMENT,
  `precototal` double NOT NULL,
  `idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idcompra`),
  KEY `idcliente` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `envolve_qtd_compra`
--

CREATE TABLE IF NOT EXISTS `envolve_qtd_compra` (
  `idlivro` int(11) NOT NULL,
  `qtd` int(11) NOT NULL,
  `idcompra` int(11) NOT NULL,
  KEY `idlivro` (`idlivro`),
  KEY `idcompra` (`idcompra`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagem`
--

CREATE TABLE IF NOT EXISTS `mensagem` (
  `idMensagem` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `mensagem` varchar(1000) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idMensagem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido`
--

CREATE TABLE IF NOT EXISTS `pedido` (
  `codPedido` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`codPedido`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidoproduto`
--

CREATE TABLE IF NOT EXISTS `pedidoproduto` (
  `email` varchar(255) NOT NULL,
  `codPedido` int(11) NOT NULL,
  `codProduto` int(11) NOT NULL,
  `preco` double NOT NULL,
  `quantd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pedidoproduto`
--

INSERT INTO `pedidoproduto` (`email`, `codPedido`, `codProduto`, `preco`, `quantd`) VALUES
('teste@teste.com', 14, 2, 4465, 1),
('teste@teste.com', 15, 11, 34, 2),
('teste@teste.com', 15, 2, 4465, 1),
('teste@teste.com', 16, 11, 34, 2),
('teste@teste.com', 16, 2, 4465, 1),
('teste@teste.com', 16, 10, 34, 1),
('teste@teste.com', 17, 11, 34, 2),
('teste@teste.com', 17, 2, 4465, 1),
('teste@teste.com', 17, 10, 34, 1),
('teste@teste.com', 18, 11, 34, 2),
('teste@teste.com', 19, 11, 34, 2),
('teste@teste.com', 20, 6, 23.23, 5),
('teste@teste.com', 20, 11, 34, 2),
('teste@teste.com', 21, 6, 23.23, 5),
('teste@teste.com', 21, 3, 23.23, 1),
('teste@teste.com', 21, 11, 34, 2),
('teste@teste.com', 23, 11, 34, 1),
('teste@teste.com', 24, 11, 34, 1),
('teste@teste.com', 25, 11, 34, 1),
('teste@teste.com', 26, 4, 34, 1),
('teste@teste.com', 27, 3, 23.23, 10),
('teste@teste.com', 28, 2, 4465, 1),
('teste@teste.com', 29, 2, 4465, 1),
('teste@teste.com', 30, 11, 34, 1),
('teste@teste.com', 30, 2, 4465, 1),
('teste@teste.com', 31, 2, 4465, 1),
('teste@teste.com', 32, 9, 34, 5),
('teste@teste.com', 32, 8, 89, 1),
('teste@teste.com', 32, 7, 45, 1),
('teste@teste.com', 32, 6, 23.23, 1),
('teste@teste.com', 32, 4, 34, 1),
('teste@teste.com', 32, 3, 23.23, 1),
('teste@teste.com', 32, 2, 4465, 3),
('teste@teste.com', 32, 10, 34, 9),
('teste@teste.com', 33, 3, 23.23, 7),
('teste@teste.com', 33, 9, 34, 1),
('teste@teste.com', 34, 3, 23.23, 2),
('teste@teste.com', 34, 2, 4465, 1),
('teste@teste.com', 34, 1, 50, 19),
('teste@teste.com', 35, 5, 34, 10),
('teste@teste.com', 35, 4, 34, 1),
('teste@teste.com', 35, 2, 4465, 150),
('teste@teste.com', 35, 7, 45, 13),
('teste@teste.com', 36, 2, 4465, 1),
('teste@teste.com', 36, 1, 50, 10),
('teste@teste.com', 37, 2, 4465, 1),
('teste@teste.com', 38, 2, 4465, 1),
('teste@teste.com', 38, 1, 50, 1),
('teste@teste.com', 39, 3, 323, 10),
('teste@teste.com', 39, 2, 80, 1),
('teste@teste.com', 39, 1, 45, 3),
('teste@teste.com', 40, 1, 45, 1),
('teste@teste.com', 40, 9, 85.95, 1),
('teste@teste.com', 41, 1, 45, 1),
('teste@teste.com', 42, 1, 45, 1),
('teste@teste.com', 43, 1, 45, 1),
('teste@teste.com', 44, 6, 84.9, 10),
('teste@teste.com', 44, 1, 45, 1),
('teste@teste.com', 44, 8, 50, 1),
('teste@teste.com', 44, 7, 104, 2),
('teste@teste.com', 45, 4, 70, 1),
('teste@teste.com', 45, 11, 49.9, 2),
('teste@teste.com', 45, 9, 85.95, 1),
('teste@teste.com', 46, 2, 80, 2),
('teste@teste.com', 47, 4, 70, 1),
('teste@teste.com', 47, 2, 80, 1),
('teste@teste.com', 47, 1, 45, 1),
('teste@teste.com', 48, 5, 85, 1),
('teste@teste.com', 48, 4, 70, 1),
('teste@teste.com', 48, 2, 80, 1),
('teste@teste.com', 48, 1, 45, 1),
('teste@teste.com', 48, 7, 104, 1),
('teste@teste.com', 49, 4, 70, 1),
('teste@teste.com', 49, 2, 80, 1),
('teste@teste.com', 49, 1, 45, 1),
('teste@teste.com', 49, 7, 104, 1),
('teste@teste.com', 50, 6, 84.9, 1),
('teste@teste.com', 50, 5, 85, 1),
('teste@teste.com', 50, 4, 70, 1),
('teste@teste.com', 50, 2, 80, 1),
('teste@teste.com', 51, 4, 70, 1),
('teste@teste.com', 51, 2, 80, 1),
('teste@teste.com', 51, 1, 45, 1),
('teste@teste.com', 53, 1, 45, 1),
('teste@teste.com', 54, 1, 45, 1),
('teste@teste.com', 56, 2, 80, 1),
('teste@teste.com', 57, 4, 70, 1),
('teste@teste.com', 58, 1, 45, 1),
('dri@gmail.com', 59, 1, 45, 1),
('teste@teste.com', 60, 11, 49.9, 2),
('teste@teste.com', 60, 1, 45, 1),
('lucas_cruz@gmail.com', 61, 4, 70, 20),
('lucas_cruz@gmail.com', 61, 1, 45, 1),
('dri@gmail.com', 62, 1, 45, 3),
('teste@teste.com', 63, 11, 49.9, 1),
('teste@teste.com', 63, 1, 45, 4),
('karem@gmail.com', 64, 2, 80, 1),
('teste@teste.com', 65, 2, 80, 4),
('teste@teste.com', 65, 1, 45, 4),
('teste@teste.com', 66, 4, 70, 1),
('dri@gmail.com', 67, 4, 70, 1),
('dri@gmail.com', 68, 4, 70, 1),
('ggg@ggg.com', 69, 2, 80, 1),
('ggg@ggg.com', 69, 9, 85.95, 1000),
('filipechandretti98@gmail.com', 70, 4, 70, 1),
('filipechandretti98@gmail.com', 70, 2, 80, 1),
('filipechandretti98@gmail.com', 70, 1, 50, 1),
('filipechandretti98@gmail.com', 71, 2, 80, 1),
('filipechandretti98@gmail.com', 72, 2, 80, 4),
('filipechandretti98@gmail.com', 72, 10, 102.34, 11);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`idcliente`);

--
-- Limitadores para a tabela `envolve_qtd_compra`
--
ALTER TABLE `envolve_qtd_compra`
  ADD CONSTRAINT `envolve_qtd_compra_ibfk_1` FOREIGN KEY (`idlivro`) REFERENCES `camiseta` (`idCamiseta`),
  ADD CONSTRAINT `envolve_qtd_compra_ibfk_2` FOREIGN KEY (`idcompra`) REFERENCES `compra` (`idcompra`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
