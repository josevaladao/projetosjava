package br.com.lojaVirtual.persistencia;

import br.com.lojaVirtual.entidade.Adm;

public class AdmDao extends Dao {
	public Adm consultarEmailSenha(String email, String senha)
			throws Exception {
		abrirConexao();
		stmt = conn.prepareStatement("select * from adm where email = ? and senha = ?");
		stmt.setString(1, email);
		stmt.setString(2, senha);

		rs = stmt.executeQuery();
		Adm Adm = null;
		if (rs.next()) {
			Adm = new Adm (rs.getInt(1), rs.getString(2),
					rs.getString(3),rs.getString(4));
		}
		rs.close();
		stmt.close();
		fecharConexao();
		return Adm;
	}
		
}
