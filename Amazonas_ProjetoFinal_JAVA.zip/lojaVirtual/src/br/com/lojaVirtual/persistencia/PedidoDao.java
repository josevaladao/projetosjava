package br.com.lojaVirtual.persistencia;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import br.com.lojaVirtual.entidade.Pedido;


public class PedidoDao extends Dao{
	
	public void inserePedido(Pedido p) throws Exception{
		abrirConexao();
		String sql ="INSERT INTO pedido(email,data)"
				+   "VALUES(?,?)";
		
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, p.getEmail()); 
			st.setTimestamp(2, p.getData());
			st.execute();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		fecharConexao();
	}
	
	public int PegaCodPedido(Timestamp datapedido) throws Exception{
		abrirConexao();
		String sql ="SELECT codPedido FROM pedido WHERE data ='"+datapedido+"'";
    	int retorno =0;
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			
			while(rs.next())
				retorno =rs.getInt(1);
			System.out.println(retorno);
			System.out.println(datapedido);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	fecharConexao();
    	return retorno;
    	
    }
	
	public int PegaUltimoCodPedido() throws Exception{
		abrirConexao();
		String sql ="SELECT codPedido FROM pedido Order by codPedido DESC LIMIT 1";
    	int retorno =0;
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next())
				retorno =rs.getInt(1);
			System.out.println(retorno);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	fecharConexao();
    	return retorno;
    	
    }

}
