package br.com.lojaVirtual.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;


import java.util.List;

import br.com.lojaVirtual.entidade.Cliente;


public class ClienteDao extends Dao {

	public void inserir(Cliente cliente) throws Exception {
		abrirConexao();

		stmt = conn.prepareStatement("Insert into cliente values (null,?,?,?,?,?,?,?,?,?)");
		stmt.setString(1, cliente.getNomeCliente());
		stmt.setString(2, cliente.getEmail());
		stmt.setString(3, cliente.getSenha());
		stmt.setString(4, cliente.getRg());
		stmt.setString(5, cliente.getCpf());
		stmt.setString(6, cliente.getCep());
		stmt.setString(7, cliente.getCidade());
		stmt.setString(8, cliente.getBairro());
		stmt.setString(9, cliente.getLogradouro());

		stmt.execute();
		stmt.close();

		fecharConexao();

	}

	public Cliente consultarEmailSenha(String email, String senha)
			throws Exception {
		abrirConexao();
		stmt = conn.prepareStatement("select idcliente,nomecliente, email from cliente where email = ? and senha = ?");
		stmt.setString(1, email);
		stmt.setString(2, senha);

		rs = stmt.executeQuery();
		Cliente Cliente = null;
		if (rs.next()) {
			Cliente = new Cliente(rs.getInt(1), rs.getString(2),
					rs.getString(3), null, senha, senha, senha, senha, senha,
					senha);
		}
		rs.close();
		stmt.close();
		fecharConexao();
		return Cliente;
	}

	// Metodo de buscar...
	public List<Cliente> buscarCliente(String nomecliente) throws Exception {

		abrirConexao();
		stmt = conn.prepareStatement("select * from cliente where nomecliente like ?");
		stmt.setString(1, nomecliente + "%");

		rs = stmt.executeQuery();

		List<Cliente> lista = new ArrayList<Cliente>();

		while (rs.next()) {
			Cliente cliente = new Cliente(rs.getInt("idCliente"),
					rs.getString("nomeCliente"), rs.getString("email"),
					rs.getString("senha"), rs.getString("rg"),
					rs.getString("cpf"), rs.getString("cep"),
					rs.getString("cidade"), rs.getString("bairro"),
					rs.getString("logradouro"));

			lista.add(cliente);
		}
		fecharConexao();
		return lista;
	}

	// Metodo de excluir
	public void excluirCliente(int idCliente) throws Exception {
		abrirConexao();
		;

		stmt = conn.prepareStatement("delete from cliente where idcliente = ?");
		stmt.setInt(1, idCliente);
		stmt.execute();
		fecharConexao();
	}

	// Metodo de editar
	public void editarcliente(Cliente client) throws Exception {
		abrirConexao();

		stmt = conn.prepareStatement("update cliente set nomecliente = ? , email= ? , senha = ? , rg = ?, cpf = ?, cep = ?,cidade = ? , bairro = ?, logradouro = ?   where idcliente = ?");

		stmt.setString(1, client.getNomeCliente());
		stmt.setString(2, client.getEmail());
		stmt.setString(3, client.getSenha());
		stmt.setString(4, client.getRg());
		stmt.setString(5, client.getCpf());
		stmt.setString(6, client.getCep());
		stmt.setString(7, client.getCidade());
		stmt.setString(8, client.getBairro());
		stmt.setString(9, client.getLogradouro());
		stmt.setInt(10, client.getIdCliente());

		stmt.execute();
		fecharConexao();

	}

	public Cliente buscarPorIdcliente(int idCliente) throws Exception {
		abrirConexao();
		stmt = conn.prepareStatement("select * from cliente where idcliente = ? ");

		stmt.setInt(1, idCliente);

		Cliente cliente = null;
		rs = stmt.executeQuery();
		if (rs.next()) {
			cliente = new Cliente(rs.getInt("idCliente"),
					rs.getString("nomeCliente"), 
					rs.getString("email"),
					rs.getString("senha"),
					rs.getString("rg"),
					rs.getString("cpf"),
					rs.getString("cep"),
					rs.getString("cidade"), 
					rs.getString("bairro"),
					rs.getString("logradouro"));

		}
		fecharConexao();
		return cliente;
	}
	
    public Cliente pegaDados(String email) throws Exception{
    	abrirConexao();
		Cliente c = new Cliente();
		c.setEmail(email);
		String sql = "SELECT * FROM cliente WHERE email='"+email+"'";
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				c.setNomeCliente(rs.getString("nomeCliente"));
				c.setCep(rs.getString("cep"));
				c.setCidade(rs.getString("cidade"));
				c.setBairro(rs.getString("bairro"));
				c.setLogradouro(rs.getString("logradouro"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	fecharConexao();
    	return c;
    	
    }
    
    public void alteraEndereco(String cidade, String bairro, String logradouro,String cep, String email) throws Exception{
    	abrirConexao();
    	String sql ="Update cliente set email='"+email+"', cep='"+cep+"', cidade='"+cidade+"', bairro='"
    			   + bairro+"', logradouro='"+logradouro+"' WHERE email='"+email+"'";
    	try {
    		stmt = conn.prepareStatement(sql);
			stmt.executeUpdate();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	fecharConexao();
    }
    
    public String pegaSenha(String email) throws Exception{
    	abrirConexao();
		String sql ="SELECT senha FROM cliente WHERE email ='"+email+"'";
		String retorno = null;
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next())
				retorno = rs.getString("senha");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		fecharConexao();
		return retorno;
	}
    
    public Cliente buscarEnderecoPorIdcliente(int id) throws Exception {
		abrirConexao();
		stmt = conn.prepareStatement("select cep,cidade,bairro,logradouro from cliente where idcliente = ? ");

		stmt.setInt(1, id);

		Cliente cliente = null;
		rs = stmt.executeQuery();
		if (rs.next()) {
			cliente = new Cliente(rs.getInt("idcliente"),
					rs.getString("nomecliente"), 
					rs.getString("email"),
					rs.getString("senha"),
					rs.getString("rg"),
					rs.getString("cpf"),
					rs.getString("cep"),
					rs.getString("cidade"), 
					rs.getString("bairro"),
					rs.getString("logradouro"));

		}
		fecharConexao();
		return cliente;
	}
    
    public Cliente pegaId(String email) throws Exception{
    	abrirConexao();
		Cliente c = new Cliente();
		c.setEmail(email);
		String sql = "SELECT idcliente FROM cliente WHERE email='"+email+"'";
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				c.setIdCliente(rs.getInt("idcliente"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	fecharConexao();
    	return c;
    	
    }
}
