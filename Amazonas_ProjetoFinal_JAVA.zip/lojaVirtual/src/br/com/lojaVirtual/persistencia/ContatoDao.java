package br.com.lojaVirtual.persistencia;

import br.com.lojaVirtual.entidade.Contato;

public class ContatoDao extends Dao {

public void contato(Contato cont)throws Exception{
	abrirConexao();
	stmt = conn.prepareStatement("insert into mensagem values(null,?,?,?)");
	stmt.setString(1, cont.getNome());
	stmt.setString(2, cont.getEmail());
	stmt.setString(3, cont.getMensagem());



	stmt.execute();
	fecharConexao();
	}

}

