package br.com.lojaVirtual.persistencia;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dao {
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;
	
	
	public void abrirConexao()throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/camiseteria","root","");
		
	}
	public void fecharConexao()throws Exception {
		conn.close();
		
	}
	
	public static void main(String[] args) {
		try {
			Dao d = new Dao ();
			d.abrirConexao();
			System.out.println("Conectado!....");
			d.fecharConexao();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("deu ruim!....");
		}
	}
}
