package br.com.lojaVirtual.persistencia;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


import br.com.lojaVirtual.entidade.Camiseta;


public class CamisetaDao extends Dao {
	

	//Metodo de cadastrar
	
	public void cadastrar(Camiseta camiseta)throws Exception {
		
		abrirConexao();
		stmt = conn.prepareStatement("insert into camiseta values(null,?,?,?,?,?,?,?,?,?,?,?,?)");
		
		stmt.setString(1, camiseta.getNome());
		stmt.setString(2, camiseta.getImagem());
		stmt.setString(3, camiseta.getDescricao());
		stmt.setDouble(4,camiseta.getPreco());
		stmt.setString(5, camiseta.getMarca());
		stmt.setString(6, camiseta.getCor());
		stmt.setString(7, camiseta.getGenero());
		stmt.setInt(8, camiseta.getQuantidadeP());
		stmt.setInt(9, camiseta.getQuantidadeM());
		stmt.setInt(10, camiseta.getQuantidadeG());
		stmt.setInt(11, camiseta.getQuantidadeGG());
		stmt.setInt(12, camiseta.getQuantidadeXG());
		
		stmt.execute();
		fecharConexao();
		
	}

	
	//Metodo de buscar
	
	public List<Camiseta> buscar(String nome)throws Exception {
		
		abrirConexao();		
		stmt = conn.prepareStatement("select * from camiseta where nome like ?");
		stmt.setString(1, nome + "%");
		
		rs = stmt.executeQuery();
		
		List<Camiseta> lista = new ArrayList<Camiseta>();
		
		while (rs.next()){
			Camiseta camiseta = new Camiseta(rs.getInt("idCamiseta"),
										rs.getString("nome"),
										rs.getString("imagem"),
										rs.getString("descricao"),
										rs.getDouble("preco"),
										rs.getString("marca"),
										rs.getString("cor"),
										rs.getString("genero"),
										rs.getInt("quantidadeP"),
										rs.getInt("quantidadeM"),
										rs.getInt("quantidadeG"),
										rs.getInt("quantidadeGG"),
										rs.getInt("quantidadeXG"));
			
			lista.add(camiseta);
		}
		fecharConexao();
		return lista;
		
	}
	
	
	//Metodo de excluir
	public void excluirCamiseta(int id) throws Exception  {
		abrirConexao();
		
		stmt = conn.prepareStatement("delete from camiseta where idCamiseta= ?");
		stmt.setInt(1,id);
		stmt.execute();
		fecharConexao();
	}
	
	//Metodo de editar
	public void  editarCamiseta(Camiseta cam) throws Exception {
		abrirConexao();
		
		stmt = conn.prepareStatement("update camiseta set nome = ? , imagem = ? ,descricao= ? , preco = ? , marca = ?, cor = ?, genero = ?, quantidadeP = ?, quantidadeM = ?, quantidadeG = ?, quantidadeGG = ?, quantidadeXG = ? where idCamiseta = ?");
		
	
		stmt.setString(1, cam.getNome());
		stmt.setString(2, cam.getImagem());
		stmt.setString(3, cam.getDescricao());
		stmt.setDouble (4, cam.getPreco());
		stmt.setString(5, cam.getMarca());
		stmt.setString(6, cam.getCor());
		stmt.setString(7, cam.getGenero());
		stmt.setInt(8, cam.getQuantidadeP());
		stmt.setInt(9, cam.getQuantidadeM());
		stmt.setInt(10, cam.getQuantidadeG());
		stmt.setInt(11, cam.getQuantidadeGG());
		stmt.setInt(12, cam.getQuantidadeXG());
		stmt.setInt(13, cam.getIdcamiseta());
		
		
		stmt.execute();
		fecharConexao();
		
	}
	
	public Camiseta buscarPorId(int id ) throws Exception{
		abrirConexao();
		stmt = conn.prepareStatement("select * from camiseta where idCamiseta = ? ");
		
		stmt.setInt(1,id);	
	
		rs = stmt.executeQuery();
		Camiseta camiseta = null;
		if(rs.next()){
			 camiseta = new Camiseta(rs.getInt("idCamiseta"),
					 rs.getString("nome"),
						rs.getString("imagem"),
						rs.getString("descricao"),
						rs.getDouble("preco"),
						rs.getString("marca"),
						rs.getString("cor"),
						rs.getString("genero"),
						rs.getInt("quantidadeP"),
						rs.getInt("quantidadeM"),
						rs.getInt("quantidadeG"),
						rs.getInt("quantidadeGG"),
						rs.getInt("quantidadeXG"));
			 		
			 

				
			
		}					
		fecharConexao();
		return camiseta;
	}
	
	
	public ArrayList<Camiseta> pegaLista() throws Exception{
		abrirConexao();
		ArrayList<Camiseta> lista = new ArrayList<Camiseta>();
		
		
		try {
			stmt = conn.prepareStatement("select * from camiseta");
			rs = stmt.executeQuery();
			while(rs.next()){
				Camiseta c = new Camiseta();
				c.setIdcamiseta(rs.getInt(1));
				c.setNome(rs.getString(2));
				c.setImagem(rs.getString(3));
				c.setDescricao(rs.getString(4));
				c.setPreco(rs.getDouble(5));
				c.setQuantidadeP(rs.getInt(9));
				c.setQuantidadeM(rs.getInt(10));
				c.setQuantidadeG(rs.getInt(11));
				c.setQuantidadeGG(rs.getInt(12));
				c.setQuantidadeXG(rs.getInt(13));
				lista.add(c);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		fecharConexao();
		return lista;
		
	}
	
	public Camiseta pegaCamiseta(int idCamiseta) throws Exception{
		abrirConexao();
    	String sql = "SELECT * FROM camiseta where idCamiseta ="+idCamiseta;
		Camiseta c = new Camiseta();
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while(rs.next()){
				c.setIdcamiseta(rs.getInt(1));
				c.setNome(rs.getString(2));
				c.setPreco(rs.getDouble(5));
			}
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
		fecharConexao();
		return c;
    	
    }
	
	
	
	
	
	
}
	

