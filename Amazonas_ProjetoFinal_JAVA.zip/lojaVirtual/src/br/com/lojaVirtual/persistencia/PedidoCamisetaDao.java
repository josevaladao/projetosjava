package br.com.lojaVirtual.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.lojaVirtual.entidade.PedidoCamiseta;

public class PedidoCamisetaDao extends Dao {

	
	
	public void inserePedidoCamiseta(PedidoCamiseta c) throws Exception{
		abrirConexao();
		
		stmt = conn.prepareStatement("INSERT INTO pedidoProduto(email,codPedido,codProduto,preco,quantd) VALUES(?,?,?,?,?)");
		
		stmt.setString(1, c.getEmail()); 
		stmt.setInt(2, c.getCodPedido());
		stmt.setInt(3, c.getCodProduto());
		stmt.setDouble(4, c.getPreco());
		stmt.setInt(5, c.getQuantd());
		
		stmt.execute();
		fecharConexao();
		
		
	}
    public ArrayList<PedidoCamiseta> pegaDados(String email, int codpedido) throws Exception{
    	abrirConexao();
		String sql = "SELECT * FROM pedidoProduto WHERE email ='"+email+"' and"
				+ " codPedido="+codpedido;
		ArrayList<PedidoCamiseta> lista = new ArrayList<PedidoCamiseta>();
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				PedidoCamiseta pp = new PedidoCamiseta();
				pp.setCodProduto(rs.getInt(3));
				pp.setPreco(rs.getDouble(4));
				pp.setQuantd(rs.getInt(5));
				lista.add(pp);
			}
			//System.out.println(lista.size());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	fecharConexao();
    	return lista;
    	
    }
}
