package br.com.lojademuscia.controle;

import br.com.lojademusica.dao.ProdutoDao;
import br.com.lojademusica.entidade.CarrinhoDeCompra;
import br.com.lojademusica.entidade.ItemDeCompra;
import br.com.lojademusica.entidade.Produto;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ControleCarrinho")
public class ControleCarrinho extends HttpServlet {
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try {
			String acao = request.getParameter("acao");
			if (acao.equals("addProduto")) {
				// recupera o id do produto que deve ser add no carrinho
				int idProduto = Integer.parseInt(request.getParameter("idProduto"));
				// flag para controle de inser��o de novos produtos no carrinho
				boolean existe = false;
				// recupera a sess�o pertencente ao request
				HttpSession sessao = request.getSession();
				// recupera um carrinho de produtos da sess�o
				// se n�o exite um carrinho na sess�o o valor ser� igual a null
				CarrinhoDeCompra carrinho = (CarrinhoDeCompra) sessao.getAttribute("carrinho");
				// verifica se j� exista um carrinho na sessao
				if (carrinho == null) {
					// cria um carrinho
					carrinho = new CarrinhoDeCompra();
					sessao.setAttribute("carrinho", carrinho);
				}
				// verifica se o produto existe no carrinho
				if (carrinho.getItens() != null) {
					for (ItemDeCompra item : carrinho.getItens()) {
						if (item.getProduto().getId() == idProduto) {
							// incrementa a quantidade
							item.setQuantidade(item.getQuantidade() + 1);
							existe = true;
						}
					}
				}

				// se n�o existe o item ou produto, cria um novo
				if (existe == false) {
					// encontra o produto no banco
					Produto produto = new ProdutoDao().consultarPorId(idProduto);
					// cria um novo item
					ItemDeCompra novoItem = new ItemDeCompra();
					novoItem.setProduto(produto);
					novoItem.setQuantidade(1);
					// adiciona novo item
					carrinho.addNovoItem(novoItem);
				}
				// carrega a pagina do carrinho de compras
				request.getRequestDispatcher("/carrinho.jsp").forward(request, response);
			} // fim addProduto
				// remove um produto da soma
			if (acao.equals("remProduto")) {
				// recupera o id do produto que deve ser add no carrinho
				int idProduto = Integer.parseInt(request.getParameter("idProduto"));
				// flag para controle de inser��o de novos produtos no carrinho
				boolean existe = false;
				// recupera a sess�o pertencente ao request
				HttpSession sessao = request.getSession();
				// recupera um carrinho de produtos da sess�o
				// se n�o exite um carrinho na sess�o o valor ser� igual a null
				CarrinhoDeCompra carrinho = (CarrinhoDeCompra) sessao.getAttribute("carrinho");
				// verifica se j� exista um carrinho na sessao
				if (carrinho == null) {
					// cria um carrinho
					carrinho = new CarrinhoDeCompra();
					sessao.setAttribute("carrinho", carrinho);
				}

				// verifica se o produto existe no carrinho
				if (carrinho.getItens() != null) {
					for (ItemDeCompra item : carrinho.getItens()) {
						if (item.getProduto().getId() == idProduto) {
							if (item.getQuantidade() > 1) {
								// decrementa a quantidade
								item.setQuantidade(item.getQuantidade() - 1);
								existe = true;
							}else {
								// recupera a sess�o pertencente ao request
								sessao = request.getSession();
								// recupera um carrinho de produtos da sess�o
								carrinho = (CarrinhoDeCompra) sessao.getAttribute("carrinho");
								// recupera o id do produto
								idProduto = Integer.parseInt(request.getParameter("idProduto"));
								ItemDeCompra itemRemove = new ItemDeCompra();
								Produto prodRemove = new Produto();
								prodRemove.setId(idProduto);
								itemRemove.setProduto(prodRemove);
								carrinho.removerItem(itemRemove);
								// carrega a pagina do carrinho de compras
								request.getRequestDispatcher("/carrinho.jsp").forward(request, response);
							}
						}
					}
				}

				/*
				 * // se n�o existe o item ou produto, cria um novo if (existe == false) { //
				 * encontra o produto no banco Produto produto = new
				 * ProdutoDao().consultarPorId(idProduto); // cria um novo item ItemDeCompra
				 * novoItem = new ItemDeCompra(); novoItem.setProduto(produto);
				 * novoItem.setQuantidade(1); // adiciona novo item
				 * carrinho.addNovoItem(novoItem); }
				 */
				// carrega a pagina do carrinho de compras
				request.getRequestDispatcher("/carrinho.jsp").forward(request, response);
			} // fim remProduto

			else if (acao.equals("removeProduto")) {
				// recupera a sess�o pertencente ao request
				HttpSession sessao = request.getSession();
				// recupera um carrinho de produtos da sess�o
				CarrinhoDeCompra carrinho = (CarrinhoDeCompra) sessao.getAttribute("carrinho");
				// recupera o id do produto
				int idProduto = Integer.parseInt(request.getParameter("idProduto"));
				ItemDeCompra itemRemove = new ItemDeCompra();
				Produto prodRemove = new Produto();
				prodRemove.setId(idProduto);
				itemRemove.setProduto(prodRemove);
				carrinho.removerItem(itemRemove);
				// carrega a pagina do carrinho de compras
				request.getRequestDispatcher("/carrinho.jsp").forward(request, response);
			} else if (acao.equals("cancelaCompra")) {
				// recupera a sess�o pertencente ao request
				HttpSession sessao = request.getSession();
				// remove o carrinho da sess�o
				sessao.removeAttribute("carrinho");
				// redireciona para pagina principal
				response.sendRedirect("index.jsp");
			}
		} catch (Exception erro) {
			request.setAttribute("erro", erro);
			request.getRequestDispatcher("/erro.jsp").forward(request, response);
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
}