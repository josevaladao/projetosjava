package br.com.lojademusica.entidade;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CarrinhoDeCompra {	
	
	private Integer id;
	private List<ItemDeCompra> itens;	
	private double total;
	
	public void addNovoItem(ItemDeCompra item) {
		if(this.itens == null) {
			this.itens = new ArrayList<ItemDeCompra>();
		}
		this.itens.add(item);
	}
	public void removerItem(ItemDeCompra itemRemove) {
		for(Iterator<ItemDeCompra> i = itens.iterator();i.hasNext();){
			ItemDeCompra item = (ItemDeCompra) i.next();
			if(item.getProduto().getId() == itemRemove.getProduto().getId()) {
				i.remove();
			}
		}
	}
	public double calculaTotal() {
		double vTotal = 0;
		for(ItemDeCompra item : this.itens) {
			vTotal += item.getTotal();
		}
		this.total = vTotal;
		return total;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public List<ItemDeCompra> getItens() {
		return itens;
	}
	public void setItens(List<ItemDeCompra> itens) {
		this.itens = itens;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	

}
