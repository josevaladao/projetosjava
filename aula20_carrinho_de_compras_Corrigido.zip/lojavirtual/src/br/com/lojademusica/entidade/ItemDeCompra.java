package br.com.lojademusica.entidade;

public class ItemDeCompra {
	
	private Integer id;
	private Produto produto;
	private Integer quantidade;
	private double total;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}	
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	public double getTotal() {
		this.total = this.quantidade * this.produto.getPrecoUnitario();
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
}
