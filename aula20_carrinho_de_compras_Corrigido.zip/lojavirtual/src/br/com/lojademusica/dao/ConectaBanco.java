package br.com.lojademusica.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectaBanco {
	public static Connection getConexao() {
		Connection conexao = null;
		try {
			// driver que ser� utilizado
			Class.forName("com.mysql.jdbc.Driver");
			// cria um objeto de conexao com um banco especificado no caminho...
			conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/lojavirtualcarrinho","root","");
			System.out.println("Conectou...");
		} catch (ClassNotFoundException erro1) {
			throw new RuntimeException(erro1);
		} catch (SQLException erro2) {
			throw new RuntimeException(erro2);
		}
		return conexao;
	}
}