package br.com.lojademusica.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.lojademusica.entidade.Produto;

public class ProdutoDao {
	private static final String SELECTALL = "select * from produto";
	private static final String SELECTID = "select * from produto where id = ?";

	public ArrayList<Produto> listar() {
		Connection conexao = null;
		ArrayList<Produto> listaProduto = new ArrayList<Produto>();
		try {
			conexao = ConectaBanco.getConexao();
			PreparedStatement pstmt = conexao.prepareStatement(SELECTALL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Produto prod = new Produto();
				prod.setId(rs.getInt("id"));
				prod.setNome(rs.getString("nome"));
				prod.setDescricao(rs.getString("descricao"));
				prod.setPrecoUnitario(rs.getDouble("precoUnitario"));
				prod.setImagem(rs.getString("imagem"));
				listaProduto.add(prod);
			}
		} catch (SQLException ex1) {
			throw new RuntimeException(ex1);
		} finally {
			try {
				if (conexao != null) {
					conexao.close();
				}
			} catch (SQLException ex1) {
				throw new RuntimeException(ex1);
			}
		}
		// retorna a lista
		return listaProduto;
	}

	public Produto consultarPorId(int id) {
		Connection conexao = null;
		Produto produto = new Produto();
		try {
			conexao = ConectaBanco.getConexao();
			PreparedStatement pstmt = conexao.prepareStatement(SELECTID);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				produto.setId(rs.getInt("id"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPrecoUnitario(rs.getDouble("precoUnitario"));
				produto.setImagem(rs.getString("imagem"));
			}
		} catch (SQLException ex1) {
			throw new RuntimeException(ex1);
		} finally {
			try {
				if (conexao != null) {
					conexao.close();
				}
			} catch (SQLException ex2) {
				throw new RuntimeException(ex2);
			}
		}
		return produto;
	}
}