package br.com.lojademusica.dao;

import java.sql.Connection;

public class TesteConexao {
	public static void main(String[] args) {
		@SuppressWarnings("static-access")
		Connection con = new ConectaBanco().getConexao();
		
		if(con != null) {
			System.out.println("Conex�o com sucesso!!!");
		}else {
			System.out.println("Erro na conex�o!!!");
		}
	}

}
