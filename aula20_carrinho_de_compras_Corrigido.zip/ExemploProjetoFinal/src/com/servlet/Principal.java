package com.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import com.modelo.CarregaDados;

@WebServlet("/Listagem")
public class Principal extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CarregaDados cd = new CarregaDados();
		cd.Carrega();
		response.sendRedirect("lista.jsp");
		
	}

}