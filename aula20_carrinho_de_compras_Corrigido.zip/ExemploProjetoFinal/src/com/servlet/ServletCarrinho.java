package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Carrinho")
public class ServletCarrinho extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// Declara SESSION
	HttpSession sessao;
	// Declara ARRAY
	String[][] lista = new String[10][4];
	// Declara variavel para ITEM
	int item = 0;
	// Declara variavel para verificar SESSION VENDA
	boolean verifV = false;
	
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Coleta dos Dados do Formulario
		int idP = Integer.parseInt(request.getParameter("idP"));
		String nome = request.getParameter("nome");
		int quant = Integer.parseInt(request.getParameter("quant"));
		float valor = Float.parseFloat(request.getParameter("valor"));
		
		//Coleta dos Dados da SESSION
		sessao = request.getSession();
		
		// Recupera dados da SESSION
		if(sessao.getAttribute("item") != null){
			item = (int) sessao.getAttribute("item");
		}else{
			sessao.setAttribute("item", 0);
		}
		
		// Atribui valor no ARRAY
		if(item<10){
			lista[item][0] = String.valueOf(idP);
			lista[item][1] = nome;
			lista[item][2] = String.valueOf(quant);
			lista[item][3] = String.valueOf(valor);
		}else{
			System.out.println("Carrinho Cheio!!!");
		}
		
		// Atribui Paramentro na SESSION ativa
		sessao.setAttribute("lista", lista);
		sessao.setAttribute("item", (item+1));
		
		// Redireciona para a uma pagina
		response.sendRedirect("teste.jsp");
		
		//Verificar se ja existe SESSION da VENDA
		int idV = (int) sessao.getAttribute("idV");
		if(idV==0){
			System.out.println("Venda Nao Cadastrada");
		}else{
			verifV = true;
		}
		
		/* 1 - Usuario Logado? R: Verificar se idU != 0
		 * 2 - Tem Item no Carrinho? R: Verificar listagem[x][y] != null
		 * 3 - Tem SESSION Venda ativa? R: Verificar se idV != 0
		 * 4 - Se SESSION Venda ativa, Desativar.
		 * 		- Verificar se ultimo lancamento na tabela venda esta com idU atual e totVenda = 0
		 * 		- Se idU do ultimo lancamento diferente e totVenda 0, apagar esse registro
		 * 5 - Preparar Estrutura para receber dados do ARRAY Listagem   
		 */
		
		
		//Cadastrar VENDA
				/* 1 - Consultar no BD, se ja existe venda ZERADA para o idU */
				/* 2 - Cadastrar uma NOVA VENDA e criar uma SESSION para essa venda */
		
		
	}
	
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[][] listaVazia = new String[10][4];
		sessao = request.getSession();
		sessao.setAttribute("item", 0);
		sessao.setAttribute("lista", listaVazia);
		response.sendRedirect("teste.jsp");
	}

}









