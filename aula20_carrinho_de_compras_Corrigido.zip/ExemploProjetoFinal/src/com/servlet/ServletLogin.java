package com.servlet;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.modelo.Consulta;

@WebServlet("/Login")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession sessao;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		sessao = request.getSession();
		String u = request.getParameter("txtUsuario");
		String s = request.getParameter("txtSenha");
		System.out.println(u + s);
		if(("".equals(u))&&("".equals(s))){
			request.setAttribute("msg","Campo(s) Vazio(s)!");
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request,response);
		}else{
			Consulta c = new Consulta();
			c.ConsultarLogin(u, s);
			boolean retorno = c.RetornaLogin();
			if(retorno == true){
				sessao.setAttribute("usuario", u);
				sessao.setAttribute("idU", c.RetornaIdLogin());
				response.sendRedirect("index.jsp");
			}else{
				request.setAttribute("msg","Login ou senha inválidos!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request,response);
			}
		}
	}
	
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[][] listaVazia = new String[10][4];
		sessao = request.getSession();
		sessao.setAttribute("usuario", "");
		sessao.setAttribute("idU", 0);
		sessao.setAttribute("idV", 0);
		sessao.setAttribute("item", 0);
		sessao.setAttribute("lista", listaVazia);
		response.sendRedirect("index.jsp");
	}

}













