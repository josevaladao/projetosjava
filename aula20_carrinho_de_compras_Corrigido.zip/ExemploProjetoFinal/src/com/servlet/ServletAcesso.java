package com.servlet;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.modelo.Consulta;

@WebServlet("/Login2")
public class ServletAcesso extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession sessao;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		sessao = request.getSession();
		String usu = request.getParameter("TxtUsuario");
		String sen = request.getParameter("TxtSenha");
		Consulta c = new Consulta();
		c.ConsultarLogin(usu, sen);
		boolean retorno = c.RetornaLogin();
		if(retorno == true){
			sessao.setAttribute("usuario", usu);
			response.getWriter().append("Usuario Logado Com Sucesso!!!");
			response.sendRedirect("index.jsp");
		}else{
			response.getWriter().append("Usuario e/ou Senha Invalidos!!!");
		}
	}
	
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		sessao = request.getSession();
		sessao.setAttribute("usuario", "");
		response.sendRedirect("index.jsp");
	}

}
