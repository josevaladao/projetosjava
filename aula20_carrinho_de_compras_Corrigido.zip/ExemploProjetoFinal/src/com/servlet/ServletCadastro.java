package com.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.modelo.Cadastro;
import com.modelo.Consulta;


@WebServlet("/Cadastro")
public class ServletCadastro extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nom = request.getParameter("TxtNome");
		String sobnom = request.getParameter("TxtSobreNome");
		String tur = request.getParameter("idT");
		Consulta c = new Consulta();
		Cadastro cc = new Cadastro();
		c.ConsultarCadastro(nom ,sobnom);
		boolean retorno = c.RetornaCadastro();
		if(retorno == true){
			response.getWriter().append("Aluno J� Cadastrado!!!");
		}else{
			cc.Cadastrar(nom,sobnom,tur);
			if(cc.RetornaCadastro() == true){
				response.getWriter().append("Aluno Cadastrado Com Sucesso!!!");
			}else{
				response.getWriter().append("Aluno N�o Cadastrado!!!");
			}
		}
	}

}

















