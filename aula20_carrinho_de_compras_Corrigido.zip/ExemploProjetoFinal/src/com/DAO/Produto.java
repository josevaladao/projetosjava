package com.DAO;

public class Produto {
	
	int ID;
	String Nome;
	String SobreNome;
	int Turma;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getSobreNome() {
		return SobreNome;
	}
	public void setSobreNome(String sobreNome) {
		SobreNome = sobreNome;
	}
	public int getTurma() {
		return Turma;
	}
	public void setTurma(int turma) {
		Turma = turma;
	}

}
