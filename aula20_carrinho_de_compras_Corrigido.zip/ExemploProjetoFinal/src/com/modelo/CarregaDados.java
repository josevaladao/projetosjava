package com.modelo;

import java.sql.*;
import com.DAO.Produto;

public class CarregaDados{
	
	Produto a = new Produto();
	Conexao c = new Conexao();
	public int id[] = new int[10];
	public String nome[] = new String[10];
	public String sobrenome[] = new String[10];
	public int turma[] = new int[10];
	int i = 0;

	public void Carrega(){
		try{
			c.Conecta();
			Statement st = c.con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM aluno;");
			while(rs.next()){
				// Carregou SET
				a.setID(rs.getInt("matAlu"));
				a.setNome(rs.getString("nomAlu"));
				a.setSobreNome(rs.getString("sobnomAlu"));
				a.setTurma(rs.getInt("idT"));
				// Disparar GET
				id[i] = a.getID();
				nome[i] = a.getNome();
				sobrenome[i] = a.getSobreNome();
				turma[i] = a.getTurma();
				i++;
			}
			rs.close();
			st.close();
			c.Desconecta();
		}catch(SQLException err){
			System.out.println("ERRO: " + err);
		}
	}

}