package com.modelo;

import java.sql.*;

public class Cadastro {
	
	Conexao cn = new Conexao();
	int verifica;
	boolean msg = false; 
	
	public void Cadastrar(String n, String s, String t){
		try{
			String sql = "INSERT INTO aluno(nomAlu,sobnomAlu,idT) VALUES "+
					"('"+n+"','"+s+"', "+t+");";
			cn.Conecta();
			Statement st = cn.con.createStatement();
			verifica = st.executeUpdate(sql);
			st.close();
			cn.Desconecta();
		}catch(SQLException err){
			System.out.println("ERRO: " + err);
		}
		
		if(verifica == 1){
			msg = true;
		}else{
			msg = false;
		}
	}
	
	public boolean RetornaCadastro(){
		return msg;
	}

}
