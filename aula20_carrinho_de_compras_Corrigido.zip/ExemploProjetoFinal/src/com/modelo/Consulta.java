package com.modelo;

import java.sql.*;
import com.modelo.Conexao;

public class Consulta {
	
	Conexao cn = new Conexao();
	String sql = "";
	public boolean msg = false;
	public int idU = 0;
	
	public void ConsultarLogin(String u, String s){
		try{
			sql = "SELECT * FROM usuario;";
			cn.Conecta();
			Statement st = cn.con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				String usuario = rs.getString("usuario");
				String senha = rs.getString("senha");
				System.out.println(usuario + senha);
				System.out.println(u + s);
				if((u.equals(usuario))&&(s.equals(senha))){
					msg = true;
					idU = rs.getInt("idU");
					break;
				}else{
					msg = false;
				}
			}
			rs.close();
			st.close();
			cn.Desconecta();
		}catch(SQLException e){
			System.out.println("ERRO: " + e);
		}
	}
	
	public boolean RetornaLogin(){
		return msg;
	}
	
	public int RetornaIdLogin(){
		return idU;
	}
	
	public void ConsultarCadastro(String n, String s){
		try{
			sql = "SELECT * FROM aluno;";
			cn.Conecta();
			Statement st = cn.con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				String nom = rs.getString("nomAlu");
				String sobnom = rs.getString("sobnomAlu");
				if((n.equals(nom))||(s.equals(sobnom))){
					msg = true;
				}else{
					msg = false;
				}
			}
			rs.close();
			st.close();
			cn.Desconecta();
		}catch(SQLException err){
			System.out.println("ERRO: " + err);
		}
	}
	
	public boolean RetornaCadastro(){
		return msg;
	}

}














