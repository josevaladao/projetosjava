package com.modelo;

import java.sql.*;

public class Conexao {
	
	public Connection con = null;
	String caminho = "jdbc:mysql://localhost:3306/aula";
	String usuBD = "root";
	String senBD = "";
	
	public void Conecta(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(caminho,usuBD,senBD);
			System.out.println("Conectou!!!");
		}catch(ClassNotFoundException | SQLException e){
			System.out.println("ERRO: " + e);
		}
	}
	
	public void Desconecta(){
		try{
			con.close();
			System.out.println("DesConectou!!!");
		}catch(SQLException e){
			System.out.println("ERRO: " + e);
		}
	}

}
















	
	
	
	