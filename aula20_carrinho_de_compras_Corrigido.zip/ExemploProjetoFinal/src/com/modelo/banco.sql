CREATE DATABASE IF NOT EXISTS site;

USE site;

CREATE TABLE usuario(
	idU INT(11) AUTO_INCREMENT PRIMARY KEY,
	nome VARCHAR(20) NOT NULL,
	usuario VARCHAR(20) NOT NULL,
	senha VARCHAR(20) NOT NULL,
	email VARCHAR(20) NOT NULL
);

INSERT INTO usuario(nome,usuario,senha,email) VALUES 
	("administrador","admin","admin","admin@mail.com"),
	("aluno tester","aluno","1234","aluno@mail.com");
	
CREATE TABLE produto(
	idP INT(11) AUTO_INCREMENT PRIMARY KEY,
	nome VARCHAR(40) NOT NULL,
	imagem VARCHAR(40) NOT NULL,
	quant INT NOT NULL,
	preco FLOAT NOT NULL,
	descricao VARCHAR(500) NOT NULL
);

INSERT INTO produto(nome,imagem,quant,preco,descricao) VALUES
	("Produto A","pa.jpg",10,9.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto B","pb.jpg",10,19.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto C","pc.jpg",10,29.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto D","pd.jpg",10,39.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto E","pe.jpg",10,49.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto F","pf.jpg",10,59.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto G","pg.jpg",10,69.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto H","ph.jpg",10,79.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto I","pi.jpg",10,89.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"),
	("Produto J","pj.jpg",10,99.99,"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum");

CREATE TABLE venda(
	idV INT(11) AUTO_INCREMENT PRIMARY KEY,
	idU INT NOT NULL,
	totVenda FLOAT NOT NULL,
	FOREIGN KEY (idU) REFERENCES usuario(idU) 
);

CREATE TABLE itemVenda(
	id INT AUTO_INCREMENT PRIMARY KEY,
	item INT NOT NULL,
	idP INT NOT NULL,
	nome VARCHAR(20) NOT NULL,
	quant INT NOT NULL,
	valor FLOAT NOT NULL,
	idV INT NOT NULL,
	FOREIGN KEY (idP) REFERENCES produto(idP),
	FOREIGN KEY (idV) REFERENCES venda(idV)
);
	
	
SHOW TABLES;
	
SELECT * FROM usuario;	
	
SELECT * FROM produto;

SELECT * FROM venda;

SELECT * FROM itemVenda;
	

	










