package br.com.jtecweb.persistence;

import java.sql.SQLException;

import br.com.jtecweb.entidade.Contato;

public class ContatoDao extends Dao{
	
	public void adicionaContato(Contato contato) throws SQLException {
		open();
		String sql = "insert into contato(nome, email,endereco)values(?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, contato.getNome());
		stmt.setString(2, contato.getEmail());
		stmt.setString(3, contato.getEndereco());
		stmt.execute();		
		close();
	}
	public void atualizaContato(Contato contato) throws SQLException {
		open();
		String sql = "update  contato set nome = ?, email = ?, endereco = ?  where id = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, contato.getNome());
		stmt.setString(2, contato.getEmail());
		stmt.setString(3, contato.getEndereco());
		stmt.setLong(4, contato.getId());
		stmt.execute();		
		close();
	}
	public void excluiContato(Contato contato) throws SQLException {
		open();
		String sql = "delete from contato where id = ?";
		stmt = con.prepareStatement(sql);		
		stmt.setLong(1, contato.getId());
		stmt.execute();		
		close();
	}
	

}
