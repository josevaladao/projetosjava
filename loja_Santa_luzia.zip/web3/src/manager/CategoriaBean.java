package manager;

import java.util.List;

import persistencia.CategoriaDao;
import entidade.Categoria;

public class CategoriaBean {
		
	private List<Categoria> listaCategoria;
	
	public CategoriaBean() {
			// no construtor vou carregar a listaCategoria
			// com os dados do banco
			try {
				listaCategoria = new CategoriaDao().listar();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}
	
	
}
