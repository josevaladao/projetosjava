create database web3;

use web3;

create table categoria (
   idcategoria int primary key auto_increment,
   nomecategoria varchar(15)
);

insert into categoria values(null,'Livros');
insert into categoria values(null,'Informatica');
insert into categoria values(null,'Eletronicos');
insert into categoria values(null,'Roupas');
insert into categoria values(null,'DVD');

create table produto(
idProduto int primary key auto_increment,
nome varchar(20) not null,
estoque int not null,
preco double(10,2) not null,
validade date not null,
id_categoria int,
foreign key(id_categoria) references categoria(idcategoria)
);
