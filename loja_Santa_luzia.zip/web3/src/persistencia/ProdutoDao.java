package persistencia;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import entidade.Categoria;
import entidade.Produto;

public class ProdutoDao extends Dao {
	
	// m�todo de cadastrar..
	public void cadastrar(Produto prod)throws Exception {
		
		open();
		stmt = con.prepareStatement("insert into produto values(null,?,?,?,?,?)");
		
		stmt.setString(1, prod.getNome());
		stmt.setInt(2, prod.getEstoque());
		stmt.setDouble(3, prod.getPreco());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, sdf.format(prod.getValidade()));	
		stmt.setInt(5, prod.getCategoria().getIdCategoria());
		
		stmt.execute();
		close();
		
	}
	
	
	// m�todo de buscar...
	public List<Produto> buscar(String nome)throws Exception {
		
		open();
		stmt = con.prepareStatement("select * produto inner join categoria"
				+ "on produto.id_categor1111ia = categoria.idcategoria = "
				+ "categoria.categoria where nome like ?");
		stmt.setString(1, nome +  "%");
		
		rs = stmt.executeQuery();
		
		List<Produto> lista = new ArrayList<Produto>();
		
		
		while (rs.next()) {
			Produto prod = new Produto(rs.getInt("idproduto"),
									   rs.getString("nome"),
									   rs.getInt("estoque"),
									   rs.getDouble("preco"),
									   rs.getDate("validade"));
			
			Categoria cat = new Categoria(rs.getInt("idcategoria"),
										  rs.getString("nomecategoria"));
			
			prod.setCategoria(cat);
			lista.add(prod);
		}
		clone();
		return lista;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// m�todo de excluir..
	// m�todo de editar...

}
