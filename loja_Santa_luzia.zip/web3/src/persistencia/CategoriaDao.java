package persistencia;

import java.util.ArrayList;
import java.util.List;

import entidade.Categoria;

public class CategoriaDao extends Dao {
	
		public List<Categoria> listar()throws Exception {
			
			open();
			// preparar a consultar...
			stmt = con.prepareStatement("select * from categoria");
			List<Categoria> lista = new ArrayList<Categoria>();
			// Executar a consulta no banco
			rs = stmt.executeQuery();
			// Enquanto existir valor na consulta... rs
			while (rs.next()) {
				// Criar uma categoria
				Categoria cat = new Categoria();
				cat.setIdCategoria(rs.getInt("idcategoria"));
				cat.setNomeCategoria(rs.getString("nomecategoria"));
				// Adicionar a categoria na lista
				lista.add(cat);
			}
			close();
			// Retornar uma lista com N categorias
			return lista;
			
		}
}
