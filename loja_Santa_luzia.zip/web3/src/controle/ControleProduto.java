package controle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import persistencia.ProdutoDao;
import entidade.Categoria;
import entidade.Produto;


@WebServlet({"/ControleProduto","/cadastrar.html"})
public class ControleProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;
         
    public ControleProduto() {
        super();
        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		execute(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		execute(request,response);
	}
	protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// Pegar a url que chamou este servlet
			String url = request.getServletPath();
			if(url.equalsIgnoreCase("/cadastrar.html")){
				cadastrar(request,response);
			}else{
				throw new Exception("URL INVALIDA!");
			}
		} catch (Exception e) {
			response.sendRedirect("index.jsp");
		}
	}
	
	protected void cadastrar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// pegar os dados do formulario para enviar ao produtoDao....
		try {
					
		String nome = request.getParameter("nome");
		String estoque = request.getParameter("estoque");
		String preco = request.getParameter("preco");
		String idcategoria = request.getParameter("categoria");
		String validade =  request.getParameter("validade");		
		
		Produto prod = new Produto();
		Categoria cat = new Categoria();		
		
		prod.setNome(nome);
		prod.setEstoque(new Integer(estoque));
		prod.setPreco(new Double(preco.replace(',', '.')));
		prod.setValidade(Produto.converterData(validade));
		
		cat.setIdCategoria(new Integer(idcategoria));
		
		// Relacionar as classes.....
		prod.setCategoria(cat);
		
		// gravar os dados no banco..... chamar o produtoDao o metodo cadastrar...
		
		ProdutoDao pd = new ProdutoDao();
		pd.cadastrar(prod);
		
		request.setAttribute("msg", "<div class='alert alert-success'>"
				+ "Produto cadastrado!</div>");
		
		
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>"
					+ "Produto n�o cadastrado!</div>");
		}finally{
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
