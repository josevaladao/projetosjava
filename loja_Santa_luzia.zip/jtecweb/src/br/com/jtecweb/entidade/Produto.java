package br.com.jtecweb.entidade;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class Produto {
	private Integer idProduto;
	private String nome;
	private Integer estoque;
	private Double preco;
	private Date validade;	
	//Todo Produto tem uma Categoria
	private Categoria categoria;
	
	public Produto() {
		
	}
	public Produto(Integer idProduto, String nome, Integer estoque, Double preco, Date validade) {
		super();
		this.idProduto = idProduto;
		this.nome = nome;
		this.estoque = estoque;
		this.preco = preco;
		this.validade = validade;
	}
	@Override
	public String toString() {
		return "Produto [idProduto=" + idProduto + ", nome=" + nome + ", estoque=" + estoque + ", preco=" + preco
				+ ", validade=" + validade + ", categoria=" + categoria + "]";
	}
	public Integer getIdProduto() {
		return idProduto;
	}
	public void setIdProduto(Integer idProduto) {
		this.idProduto = idProduto;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Integer getEstoque() {
		return estoque;
	}
	public void setEstoque(Integer estoque) {
		this.estoque = estoque;
	}
	public Double getPreco() {
		return preco;
	}
	public void setPreco(Double preco) {
		this.preco = preco;
	}
	public Date getValidade() {
		return validade;
	}
	public void setValidade(Date validade) {
		this.validade = validade;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public static Date converterData(String data){
		String[] novaData = data.split("/");
		GregorianCalendar cal = new GregorianCalendar(
				new Integer(novaData[2]),
				new Integer(novaData[1])-1,
				new Integer(novaData[0]));
		return cal.getTime();				
	}
	public String converteDateMysql(Date data) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(data);
	}
	public String converteDateInterface(Date data) {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		return df.format(data);
	}
	
}
