package br.com.jtecweb.controle;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.coyote.Request;

import br.com.jtecweb.datautil.ConverterData;
import br.com.jtecweb.entidade.Categoria;
import br.com.jtecweb.entidade.Produto;
import br.com.jtecweb.persistencia.ProdutoDao;

@WebServlet({ "/ControleProduto", "/cadastrar.html","/buscar.html","/excluir.html","/editar.html","/confirmarEditarProduto.html"})
public class ControleProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleProduto() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Pegando uma URL que chamou a Servlet
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/cadastrar.html")) {
				cadastrar(request, response);
			}else if(url.equalsIgnoreCase("/buscar.html")){
				buscar(request,response);
			}else if(url.equalsIgnoreCase("/excluir.html")){
				excluir(request,response);
			}else if(url.equalsIgnoreCase("/editar.html")){
				editar(request,response);
			}else if(url.equalsIgnoreCase("/confirmarEditarProduto.html" )){
				confirmarEditarProduto(request,response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			String nome = request.getParameter("nome");
			String estoque = request.getParameter("estoque");
			String preco = request.getParameter("preco");
			String validade = request.getParameter("validade");
			String idCategoria = request.getParameter("categoria");

			Produto prod = new Produto();
			Categoria cat = new Categoria();

			prod.setNome(nome);
			prod.setEstoque(new Integer(estoque));
			prod.setPreco(new Double(preco.replace(',', '.')));
			prod.setValidade(ConverterData.converterData(validade));

			cat.setIdCategoria(new Integer(idCategoria));

			// Relacionando as classes...
			prod.setCategoria(cat);

			// Gravando os dados no Banco de Dados

			ProdutoDao pd = new ProdutoDao();
			pd.cadastrar(prod);
			request.setAttribute("msg", "<div class='alert alert-success'>Produto Cadastrado!</div>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o Cadastrado!</div>");
		} finally {
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}

	}

	public void buscar(HttpServletRequest request, HttpServletResponse response) {
		try {
			String nomeProduto = request.getParameter("nomeProduto");
			ProdutoDao pd = new ProdutoDao();
			List<Produto> lista = pd.buscar(nomeProduto);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>Nenhum Produto Encontrado!</div>");
			}
			request.setAttribute("nomeProduto", nomeProduto);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void excluir(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			Integer idProduto = new Integer(request.getParameter("id"));
			ProdutoDao pd = new ProdutoDao();
			pd.excluir(idProduto);
			request.setAttribute("msg", "<div class='alert alert-success'>Produto Exclu�do</div>");			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o Exclu�do</div>");
		}finally {
			request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
		}
	}
	public void editar(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		try {
			//Capturando o Id do Produto vindo do formul�rio
			Integer idProduto = new Integer(request.getParameter("id"));
			Produto prod = new ProdutoDao().buscarPorIdProduto(idProduto);
			
			if(prod == null){
				request.setAttribute("msg", "<div class='alert alert-info'>Produto n�o encontrado!</div>");
				request.getRequestDispatcher("buscarProduto.jsp").forward(request, response);
			}else{
				request.setAttribute("prod", prod);
				request.getRequestDispatcher("editarProduto.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: "+e.getMessage()+"</div>");
		}
	}
	public void confirmarEditarProduto(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		try {

			String nome = request.getParameter("nome");
			String estoque = request.getParameter("estoque");
			String preco = request.getParameter("preco");
			String validade = request.getParameter("validade");
			//String idCategoria = request.getParameter("categoria");
			//Preciso declarar o id, para atualiza��o no banco de dados
			String idProduto = request.getParameter("id");
			
			Produto prod = new Produto();
			//Categoria cat = new Categoria();

			prod.setNome(nome);
			prod.setEstoque(new Integer(estoque));
			prod.setPreco(new Double(preco.replace(',', '.')));
			prod.setValidade(Produto.converterData(validade));
			prod.setIdProduto(new Integer(idProduto));

			//cat.setIdCategoria(new Integer(idCategoria));

			// Relacionando as classes...
			//prod.setCategoria(cat);

			// Gravando os dados no Banco de Dados

			ProdutoDao pd = new ProdutoDao();
			pd.editar(prod);
			request.setAttribute("msg", "<div class='alert alert-success'>Produto atualizado!</div>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o Atualizado!</div>");
		} finally {
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}

	}
	
}
