package br.com.jtecweb.datautil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.GregorianCalendar;

public class ConverterData{
	
	/*public static Date converterDataServlet(String data) {
		String[] novaData = data.split("/");
		GregorianCalendar cal = new GregorianCalendar(new Integer(novaData[2]), new Integer(novaData[1]) - 1,
				new Integer(novaData[0]));
		return cal.getTime();
	}*/

	public String converteDateMysql(Date data) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(data);
	}

	public String converteDateInterface(Date data) {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		return df.format(data);
	}
}
