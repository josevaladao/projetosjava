package br.com.jtecweb.persistencia;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweb.entidade.Categoria;
import br.com.jtecweb.entidade.Produto;

public class ProdutoDao extends Dao{
	
	public void cadastrar(Produto prod) throws ClassNotFoundException, SQLException{
		open();
		String sql = "INSERT INTO produto VALUES(null,?,?,?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, prod.getNome());
		stmt.setInt(2, prod.getEstoque());
		stmt.setDouble(3, prod.getPreco());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, sdf.format(prod.getValidade()));
		stmt.setInt(5, prod.getCategoria().getIdCategoria());
		stmt.execute();
		close();
	}
	public void editar(Produto prod) throws SQLException, ClassNotFoundException{
		open();
		String sql = "UPDATE produto WHERE idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, prod.getNome());
		stmt.setInt(2, prod.getEstoque());
		stmt.setDouble(3, prod.getPreco());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, sdf.format(prod.getValidade()));
		//stmt.setInt(5, prod.getCategoria().getIdCategoria());
		stmt.setInt(5, prod.getIdProduto());
		stmt.execute();
		close();
	}
	public void excluir(Integer id) throws ClassNotFoundException, SQLException{
		open();
		String sql = "DELETE FROM produto WHERE idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, id);
		stmt.execute();
		close();
	}
	public Produto buscarPorIdProduto(int idProduto) throws ClassNotFoundException, SQLException{
		open();
		String sql = "SELECT * FROM produto WHERE idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idProduto);
		
		Produto prod = null;
		rs = stmt.executeQuery();
		
		if(rs.next()){
			prod = new Produto(rs.getInt("idProduto"), 
					   rs.getString("nome"),
					   rs.getInt("estoque"),
					   rs.getDouble("preco"), 
					   rs.getDate("validade"));
			/*Categoria cat = new Categoria(rs.getInt("idCategoria"), 
			  rs.getString("nomeCategoria"));

			prod.setCategoria(cat);*/
		}		
		close();
		return prod;
	}
	
	public List<Produto> buscar(String nome) throws ClassNotFoundException, SQLException{
		open();
		/*String sql = "SELECT * FROM produto INNER JOIN categoria"
				+ "ON produto.id_categoria = categoria.idcategoria ="
				+ "categoria.categoria WHERE nome LIKE ?";*/
		String sql = "SELECT * FROM produto WHERE nome LIKE ?"; 
		stmt = con.prepareStatement(sql);
		stmt.setString(1, nome + "%");
		
		rs = stmt.executeQuery();
		
		List<Produto> lista = new ArrayList<Produto>();
		
		while(rs.next()){
			Produto prod = new Produto(rs.getInt("idProduto"), 
									   rs.getString("nome"),
									   rs.getInt("estoque"),
									   rs.getDouble("preco"), 
									   rs.getDate("validade"));
			
			/*Categoria cat = new Categoria(rs.getInt("idCategoria"), 
										  rs.getString("nomeCategoria"));
			
			prod.setCategoria(cat);*/
			lista.add(prod);
		}		
		close();
		return lista;
	}
}
