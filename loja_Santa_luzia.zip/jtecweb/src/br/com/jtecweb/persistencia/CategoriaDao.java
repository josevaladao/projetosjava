package br.com.jtecweb.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweb.entidade.Categoria;

public class CategoriaDao extends Dao {
	public List<Categoria> listar() throws SQLException, ClassNotFoundException{
		open();
		String sql = "SELECT * FROM categoria";
		stmt = con.prepareStatement(sql);
		List<Categoria> lista =  new ArrayList<>();
		rs = stmt.executeQuery();
		
		while(rs.next()){
			Categoria cat = new Categoria();
			cat.setIdCategoria(rs.getInt("idCategoria"));
			cat.setNomeCategoria(rs.getString("nomeCategoria"));
			
			lista.add(cat);
		}
		close();
		return lista;
	}

}
