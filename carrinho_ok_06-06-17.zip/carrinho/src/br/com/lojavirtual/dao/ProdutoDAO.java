package br.com.lojavirtual.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import br.com.lojavirtual.fabricadeconexao.FabricaConexao;
import br.com.lojavirtual.modelo.Produto;

public class ProdutoDAO {
	private Connection con;
	
	public ProdutoDAO(){
		this.con=FabricaConexao.pegaConexao("root", "");
	}
	
	public String insereProduto(Produto p){
		String sql ="INSERT INTO produto(descricao,preco)"
				+   "VALUES(?,?)";
		
		String retorno="";
		
		try {
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, p.getDescricao()); 
			st.setDouble(2, p.getPreco());
			st.execute();
			st.close();
			retorno = "Produto Inserido com �xito";
			//System.out.println(retorno);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			retorno="Erro de SQL";
		}
		return retorno;
	}
	
	public ArrayList<Produto> pegaLista(){
		ArrayList<Produto> lista = new ArrayList<Produto>();
		
		String sql = "SELECT * FROM produto";
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				Produto p = new Produto();
				p.setCodProduto(rs.getInt(1));
				p.setDescricao(rs.getString(2));
				p.setPreco(rs.getDouble(3));
				lista.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lista;
		
	}
	  public Produto pegaProduto(int codProduto){
	    	String sql = "SELECT * FROM produto where codProduto ="+codProduto;
			Produto p = new Produto();
			try {
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(sql);
				while(rs.next()){
					p.setCodProduto(rs.getInt(1));
					p.setDescricao(rs.getString(2));
					p.setPreco(rs.getDouble(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return p;
	    	
	    }
}
