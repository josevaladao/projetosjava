package br.com.lojavirtual.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import br.com.lojavirtual.fabricadeconexao.FabricaConexao;
import br.com.lojavirtual.modelo.PedidoProduto;

public class PedidoProdutoDAO {
	
private Connection con;
	
	public PedidoProdutoDAO(){
		this.con=FabricaConexao.pegaConexao("root", "");
	}	
	public void inserePedidoProduto(PedidoProduto p){
		String sql ="INSERT INTO pedidoProduto(email,codPedido,codProduto,preco,quantd)"
		          + "VALUES(?,?,?,?,?)";
		
		try {
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, p.getEmail()); 
			st.setInt(2, p.getCodPedido());
			st.setInt(3, p.getCodProduto());
			st.setDouble(4, p.getPreco());
			st.setInt(5, p.getQuantd());
			st.execute();
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    public ArrayList<PedidoProduto> pegaDados(String email, int codpedido){
		String sql = "SELECT * FROM pedidoProduto WHERE email ='"+email+"' and"
				+ " codPedido="+codpedido;
		ArrayList<PedidoProduto> lista = new ArrayList<PedidoProduto>();
		
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			while(rs.next()){
				PedidoProduto pp = new PedidoProduto();
				pp.setCodProduto(rs.getInt(3));
				pp.setPreco(rs.getDouble(4));
				pp.setQuantd(rs.getInt(5));
				lista.add(pp);
			}
			//System.out.println(lista.size());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	
    	return lista;
    	
    }
}
