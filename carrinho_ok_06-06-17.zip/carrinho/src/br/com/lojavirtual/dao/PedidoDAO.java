package br.com.lojavirtual.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import br.com.lojavirtual.fabricadeconexao.FabricaConexao;
import br.com.lojavirtual.modelo.Pedido;

public class PedidoDAO {
	
private Connection con;
	
	public PedidoDAO(){
		this.con=FabricaConexao.pegaConexao("root", "");
	}
	
	public void inserePedido(Pedido p){
		String sql ="INSERT INTO pedido(email,data)"
				+   "VALUES(?,?)";
		
		try {
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, p.getEmail()); 
			st.setTimestamp(2, p.getData());
			st.execute();
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
	
	public int PegaCodPedido(Timestamp datapedido){
		String sql ="SELECT codPedido FROM pedido WHERE data ='"+datapedido+"'";
    	int retorno =0;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
				retorno =rs.getInt(1);
			System.out.println(retorno);
			System.out.println(datapedido);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	return retorno;
    	
    }
	
	public int PegaUltimoCodPedido(){
		String sql ="SELECT codPedido FROM pedido Order by codPedido DESC LIMIT 1";
    	int retorno =0;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
				retorno =rs.getInt(1);
			System.out.println(retorno);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	return retorno;
    	
    }
}

