package br.com.lojavirtual.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import br.com.lojavirtual.fabricadeconexao.FabricaConexao;
import br.com.lojavirtual.modelo.Cliente;

public class ClienteDAO {

	private Connection con;
	
	public ClienteDAO(){
		this.con=FabricaConexao.pegaConexao("root", "");
	}
	
	public String insereCliente(Cliente c){
		String sql ="INSERT INTO cliente(email,senha,nome,rua,bairro,complemento,cep,numero,telefone)"
				+   "VALUES(?,?,?,?,?,?,?,?,?)";
		
		String retorno="";
		
		try {
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, c.getEmail());
			st.setString(2, c.getSenha());
			st.setString(3, c.getNome());
			st.setString(4, c.getRua());
			st.setString(5, c.getBairro());
			st.setString(6, c.getComplemento()); 
			st.setString(7, c.getCep());
			st.setString(8, c.getNumero());			
			st.setString(9, c.getTelefone());
			
			st.execute();
			st.close();
			retorno = "Inserido com �xito";
			System.out.println(retorno);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			retorno = "Erro de Chave Prim�ria: email repetido";
			e.printStackTrace();
		}
		return retorno;
	}
	
	
	public String pegaSenha(String email){
		String sql ="SELECT senha FROM cliente WHERE email ='"+email+"'";
		String retorno = null;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
				retorno = rs.getString("senha");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return retorno;
	}
    public Cliente pegaDados(String email){
		Cliente c = new Cliente();
		c.setEmail(email);
		String sql = "SELECT * FROM cliente WHERE email='"+email+"'";
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				c.setNome(rs.getString("nome"));
				c.setBairro(rs.getString("bairro"));
				c.setCep(rs.getString("cep"));
				c.setRua(rs.getString("rua"));
				c.setNumero(rs.getString("numero"));
				c.setComplemento(rs.getString("complemento"));
				c.setTelefone(rs.getString("telefone"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return c;
    	
    }
    public void alteraEndereco(String rua, String bairro, String nr, String compl, String cep, String email){
    	String sql ="Update cliente set rua='"+rua+"', bairro='"+bairro+"', numero='"+nr+"', complemento='"
    			   + compl+"', cep='"+cep+"' WHERE email='"+email+"'";
    	try {
			Statement st = con.createStatement();
			st.executeUpdate(sql);
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
