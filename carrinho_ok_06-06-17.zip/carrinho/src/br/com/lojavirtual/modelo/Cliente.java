/**
 * 
 */
package br.com.lojavirtual.modelo;

/**
 * @author 805-docente
 *
 */
public class Cliente {	
	private String nome;
	private String rua;
	private String bairro;
	private String numero;
	private String complemento;
	private String cep;
	private String telefone;
	private String email;
	private String senha;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public boolean validaDados(){
		boolean retorno =true;
		if(this.bairro.trim().equals("") ||
		   this.email.trim().equals("")  ||
		   this.nome.trim().equals("")   ||
		   this.rua.trim().equals("")    ||
		   this.senha.trim().equals("")  ||
		   this.numero.trim().equals("")){
			retorno=false;
			//System.out.println("epa");
		}
		
		return retorno;
	}
	
	public boolean validaSenha(String ConfSenha){
		boolean retorno=true;
		if(this.senha.equals(ConfSenha)==false)
			retorno=false;
		return retorno;
				
	}
	

}
