package br.com.lojavirtual.modelo;

import java.sql.Timestamp;

public class Pedido {
	
	private int codPedido;
	private String email;
	private Timestamp data;
	
	
	public String getEmail() {
		return email;
	}	
	
	public void setEmail(String email) {
		this.email = email;
	}
	public int getcodPedido() {
		return codPedido;
	}	
	
	public void setcodPedido(int codPedido) {
		this.codPedido = codPedido;
	}
	public Timestamp getData() {
		return data;
	}
	public void setData(Timestamp data) {
		this.data = data;
	}
	
	

}
