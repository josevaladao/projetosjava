package br.com.lojavirtual.modelo;



public class PedidoProduto {
	private String email;
	private int codPedido;
	private int codProduto;
	private double preco;
	private int quantd;

	 
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCodPedido() {
		return codPedido;
	}
	public void setCodPedido(int codPedido) {
		this.codPedido = codPedido;
	}
	public int getCodProduto() {
		return codProduto;
	}
	public void setCodProduto(int codProduto) {
		this.codProduto = codProduto;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getQuantd() {
		return quantd;
	}
	public void setQuantd(int quantd) {
		this.quantd = quantd;
	}
	
}
