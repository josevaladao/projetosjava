package br.com.lojavirtual.fabricadeconexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {
	private static Connection con;
	
	private FabricaConexao(){
		
	}
	
	public static Connection pegaConexao(String login, String senha){
		if (con == null){
			try {
				Class.forName("com.mysql.jdbc.Driver");
				//System.out.println("Achei");
			}catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
			System.out.println("N�o achei");
			}
			
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lojavirtual1",login,senha);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
			
		return con;
	}


}
