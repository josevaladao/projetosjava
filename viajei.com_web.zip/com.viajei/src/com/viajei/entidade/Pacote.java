package com.viajei.entidade;

import java.util.Calendar;

public class Pacote {
	private long idPacote;
	private String origem;
	private String destino;
	private Calendar dataIda;
	private Calendar dataVolta;
	private String horario;
	private String hospedagem;
	private String voo;
	private String assento;
	private String preco;
	private String imagem;

	public Pacote() {
		super();

	}

	public Pacote(long idPacote, String origem, String destino, Calendar dataIda, Calendar dataVolta, String horario,
			String hospedagem, String voo, String assento, String preco, String imagem) {
		super();
		this.idPacote = idPacote;
		this.origem = origem;
		this.destino = destino;
		this.dataIda = dataIda;
		this.dataVolta = dataVolta;
		this.horario = horario;
		this.hospedagem = hospedagem;
		this.voo = voo;
		this.assento = assento;
		this.preco = preco;
		this.imagem = imagem;
	}

	@Override
	public String toString() {
		return "Pacote [idPacote=" + idPacote + ", origem=" + origem + ", destino=" + destino + ", dataIda=" + dataIda
				+ ", dataVolta=" + dataVolta + ", horario=" + horario + ", hospedagem=" + hospedagem + ", voo=" + voo
				+ ", assento=" + assento + ", preco=" + preco + ", imagem=" + imagem + "]";
	}

	public long getIdPacote() {
		return idPacote;
	}

	public void setIdPacote(long idPacote) {
		this.idPacote = idPacote;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public Calendar getDataIda() {
		return dataIda;
	}

	public void setDataIda(Calendar dataIda) {
		this.dataIda = dataIda;
	}

	public Calendar getDataVolta() {
		return dataVolta;
	}

	public void setDataVolta(Calendar dataVolta) {
		this.dataVolta = dataVolta;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public String getHospedagem() {
		return hospedagem;
	}

	public void setHospedagem(String hospedagem) {
		this.hospedagem = hospedagem;
	}

	public String getVoo() {
		return voo;
	}

	public void setVoo(String voo) {
		this.voo = voo;
	}

	public String getAssento() {
		return assento;
	}

	public void setAssento(String assento) {
		this.assento = assento;
	}

	public String getPreco() {
		return preco;
	}

	public void setPreco(String preco) {
		this.preco = preco;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

}
