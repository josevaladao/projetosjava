package com.viajei.entidade;

public class Login {

	public Login(String usuario, String senha) {

	}

	public Login() {
		super();
	}

}
