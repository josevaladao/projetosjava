package com.viajei.entidade;

public class Cliente {
	private long idCliente;
	private String nome;
	private String email;
	private String usuario;
	private String senha;
	private String cpf;

	public Cliente(long idCliente, String string, String string2, String string3, String string4, String string5,
			String string6) {

	}

	public Cliente(long idCliente, String nome, String email, String usuario, String senha, String cpf) {
		super();
		this.idCliente = idCliente;
		this.nome = nome;
		this.email = email;
		this.usuario = usuario;
		this.senha = senha;
		this.cpf = cpf;
	}

	public Cliente() {

	}

	public long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(long idCliente) {
		this.idCliente = idCliente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

}
