package com.viajei.entidade;

import java.util.Calendar;

public class Compra {
	private Long idVenda;
	private Calendar dataVenda;
	private Long idPacote;
	private Long idCliente;

	public Compra() {
		super();

	}

	public Compra(Long idVenda, Calendar dataVenda, Long idPacote, Long idCliente) {
		super();
		this.idVenda = idVenda;
		this.dataVenda = dataVenda;
		this.idPacote = idPacote;
		this.idCliente = idCliente;
	}

	@Override
	public String toString() {
		return "Compra [idVenda=" + idVenda + ", dataVenda=" + dataVenda + ", idPacote=" + idPacote + ", idCliente="
				+ idCliente + "]";
	}

	public Long getIdVenda() {
		return idVenda;
	}

	public void setIdVenda(Long idVenda) {
		this.idVenda = idVenda;
	}

	public Calendar getDataVenda() {
		return dataVenda;
	}

	public void setDataVenda(Calendar dataVenda) {
		this.dataVenda = dataVenda;
	}

	public Long getIdPacote() {
		return idPacote;
	}

	public void setIdPacote(Long idPacote) {
		this.idPacote = idPacote;
	}

	public Long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}

}
