package com.viajei.persistencia;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import com.viajei.entidade.Pacote;

public class PacoteDao {
	// a conex�o com o banco de dados
	private Connection connection;

	public PacoteDao() {
		this.connection = new ConnectionFactory().getConnection();
	}

	public void adiciona(Pacote pacote) {
		String sql = "insert into pacote "
				+ "(origem,destino,dataIda,dataVolta,horario,hospedagem,voo,assento,preco,imagem)"
				+ " values (?,?,?,?,?,?,?,?,?,?)";

		try {
			// prepared statement para inser��o
			PreparedStatement stmt = connection.prepareStatement(sql);

			// seta os valores
			stmt.setString(1, pacote.getOrigem());
			stmt.setString(2, pacote.getDestino());
			stmt.setDate(3, new Date(pacote.getDataIda().getTimeInMillis()));
			stmt.setDate(4, new Date(pacote.getDataVolta().getTimeInMillis()));
			stmt.setString(5, pacote.getHorario());
			stmt.setString(6, pacote.getHospedagem());
			stmt.setString(7, pacote.getVoo());
			stmt.setString(8, pacote.getAssento());
			stmt.setString(9, pacote.getPreco());
			stmt.setString(10, pacote.getImagem());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void altera(Pacote pacote) {
		String sql = "update pacote set origem=?, destino=?, dataIda=?, dataVolta=?, horario=?, hospedagem=?, voo=?, assento=?, preco=?, imagem=? where idPacote=?";

		try {
			// prepared statement para update
			PreparedStatement stmt = connection.prepareStatement(sql);

			// seta os valores
			stmt.setString(1, pacote.getOrigem());
			stmt.setString(2, pacote.getDestino());
			stmt.setDate(3, new Date(pacote.getDataIda().getTimeInMillis()));
			stmt.setDate(4, new Date(pacote.getDataIda().getTimeInMillis()));
			stmt.setString(5, pacote.getHorario());
			stmt.setString(6, pacote.getHospedagem());
			stmt.setString(7, pacote.getVoo());
			stmt.setString(8, pacote.getAssento());
			stmt.setString(9, pacote.getPreco());
			stmt.setString(10, pacote.getImagem());
			stmt.setLong(11, pacote.getIdPacote());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void remove(Pacote pacote) {
		try {
			// prepared statement para exclus�o
			PreparedStatement stmt = connection.prepareStatement("delete from pacote where idPacote=?");

			// seta os valores
			stmt.setLong(1, pacote.getIdPacote());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Pacote> buscarPorId(int id) throws Exception {

		try {

			List<Pacote> pacotes = new ArrayList<Pacote>();
			PreparedStatement stmt = this.connection.prepareStatement("select * from pacote where idPacote=?");

			stmt.setString(1, id + "%");

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				// adicionando o objeto � lista
				pacotes.add(pacote);
			}
			rs.close();
			stmt.close();
			return pacotes;
		} catch (SQLException e) {
			throw new DAOException();
		}
	}

	public List<Pacote> lista() {
		try {

			List<Pacote> pacotes = new ArrayList<Pacote>();
			PreparedStatement stmt = this.connection.prepareStatement("select * from pacote");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				// adicionando o objeto � lista
				pacotes.add(pacote);
			}
			rs.close();
			stmt.close();
			return pacotes;
		} catch (SQLException e) {
			throw new DAOException();
		}
	}

	public List<Pacote> listaOferta() {
		try {

			List<Pacote> pacotes = new ArrayList<Pacote>();
			PreparedStatement stmt = this.connection.prepareStatement("select * from pacote where preco < 499.99");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				// adicionando o objeto � lista
				pacotes.add(pacote);
			}
			rs.close();
			stmt.close();
			return pacotes;
		} catch (SQLException e) {
			throw new DAOException();
		}
	}

	public List<Pacote> listaPrecoNormal() {
		try {

			List<Pacote> pacotes = new ArrayList<Pacote>();
			PreparedStatement stmt = this.connection.prepareStatement("select * from pacote where preco > 500.00");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				// adicionando o objeto � lista
				pacotes.add(pacote);
			}
			rs.close();
			stmt.close();
			return pacotes;
		} catch (SQLException e) {
			throw new DAOException();
		}
	}

	public List<Pacote> listaPorDestino(String destino) throws SQLException {

		try {
			PreparedStatement stmt = connection
					.prepareStatement("select * from pacote where destino like ? AND preco > 500.00");
			stmt.setString(1, destino + "%");
			ResultSet rs = stmt.executeQuery();

			List<Pacote> lista = new ArrayList<Pacote>();

			while (rs.next()) {

				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				lista.add(pacote);
			}

			rs.close();
			stmt.close();
			return lista;
		} catch (SQLException e) {
			throw new RuntimeException();
		}
	}

	public List<Pacote> buscaPrecoNormal(String destino) throws SQLException {

		try {
			PreparedStatement stmt = connection
					.prepareStatement("select * from pacote where destino like ? AND preco > 500");
			stmt.setString(1, destino + "%");
			ResultSet rs = stmt.executeQuery();

			List<Pacote> lista = new ArrayList<Pacote>();

			while (rs.next()) {
				// criando o objeto Pacote
				Pacote pacote = new Pacote();
				// setando os valores
				pacote.setOrigem(rs.getString("origem"));
				pacote.setDestino(rs.getString("destino"));

				// Tratamento de datas
				Calendar dataIda = Calendar.getInstance();
				dataIda.setTime(rs.getDate("dataIda"));
				pacote.setDataIda(dataIda);

				Calendar dataVolta = Calendar.getInstance();
				dataVolta.setTime(rs.getDate("dataVolta"));
				pacote.setDataVolta(dataVolta);

				pacote.setHorario(rs.getString("horario"));
				pacote.setHospedagem(rs.getString("hospedagem"));
				pacote.setVoo(rs.getString("voo"));
				pacote.setAssento(rs.getString("assento"));
				pacote.setPreco(rs.getString("preco"));
				pacote.setImagem(rs.getString("imagem"));
				pacote.setIdPacote(rs.getLong("idPacote"));

				lista.add(pacote);
			}

			rs.close();
			stmt.close();
			return lista;
		} catch (SQLException e) {
			throw new RuntimeException();
		}
	}

}
