package com.viajei.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import com.viajei.entidade.Compra;

public class CompraDao {

	// conex�o com o banco de dados
	private Connection connection;

	public CompraDao() {

		this.connection = new ConnectionFactory().getConnection();
	}

	public void salva(Compra compra) {
		String sql = "insert into pacotesvendidos " + "(dataVenda,idPacote,idCliente)" + " values (?,?,?)";

		try {
			// prepared statement para inser��o
			PreparedStatement stmt = connection.prepareStatement(sql);

			// seta os valores
			stmt.setDate(1, new java.sql.Date(Calendar.getInstance().getTimeInMillis()));
			stmt.setLong(2, compra.getIdPacote());
			stmt.setLong(3, compra.getIdCliente());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
