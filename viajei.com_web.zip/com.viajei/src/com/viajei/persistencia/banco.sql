CREATE DATABASE banco;
USE banco;


CREATE TABLE pacote (
idPacote BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
origem VARCHAR(50),
destino VARCHAR(50),
dataVolta DATE,
dataIda DATE,
horario VARCHAR(50),
hospedagem VARCHAR(50),
voo VARCHAR(50),
assento VARCHAR(50),
preco VARCHAR(50),
imagem VARCHAR(255)
);

CREATE TABLE cliente (
idCliente BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(50),
email VARCHAR(50) UNIQUE,
usuario VARCHAR(50) UNIQUE,
senha VARCHAR(50),
cpf VARCHAR(50) UNIQUE
);


CREATE TABLE pacotesVendidos (
idVenda BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
dataVenda DATE,
idPacote BIGINT(20),
idCliente BIGINT(20)
);


