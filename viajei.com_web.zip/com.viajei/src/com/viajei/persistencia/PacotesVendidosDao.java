package com.viajei.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.viajei.entidade.PacotesVendidos;

public class PacotesVendidosDao {
	private Connection connection;

	public PacotesVendidosDao() {
		this.connection = new ConnectionFactory().getConnection();
	}

	public void adiciona(PacotesVendidos pacotesVendidos) {
		String sql = "insert into pacotesvendidos " + "(idPagamento,dataCompra)" + " values (?,?)";

		try {
			// prepared statement para inser��o
			PreparedStatement stmt = connection.prepareStatement(sql);

			// seta os valores

			stmt.setLong(1, pacotesVendidos.getIdPagamento());
			stmt.setString(2, pacotesVendidos.getDataCompra());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
