package com.viajei.persistencia;

public class DAOException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
