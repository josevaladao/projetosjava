package com.viajei.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.viajei.entidade.Cliente;
import com.viajei.entidade.Login;

public class ClienteDao {

	// a conex�o com o banco de dados
	private Connection connection;

	public ClienteDao() {
		this.connection = new ConnectionFactory().getConnection();
	}

	public Login Login(String usuario, String senha) throws SQLException {
		String sql = "SELECT usuario, senha FROM cliente WHERE	usuario = ? AND senha = ?";
		PreparedStatement stmt = connection.prepareStatement(sql);

		stmt.setString(1, usuario);
		stmt.setString(2, senha);

		ResultSet rs = stmt.executeQuery();
		Login login = null;

		if (rs.next()) {
			login = new Login(rs.getString(1), rs.getString(2));
		}
		stmt.close();
		rs.close();
		connection.close();
		return login;
	}

	public void adiciona(Cliente cliente) {
		String sql = "insert into cliente " + "(nome,email,usuario,senha,cpf)" + " values (?,?,?,?,?)";

		try {
			// prepared statement para inser��o
			PreparedStatement stmt = connection.prepareStatement(sql);

			// seta os valores
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getUsuario());
			stmt.setString(4, cliente.getSenha());
			stmt.setString(5, cliente.getCpf());

			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void altera(Cliente cliente) {
		String sql = "update cliente set nome=?, email=?," + "usuario=?, senha=?, cpf=? where idCliente=?";

		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getUsuario());
			stmt.setString(4, cliente.getSenha());
			stmt.setString(5, cliente.getCpf());
			stmt.setLong(6, cliente.getIdCliente());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void remove(Cliente cliente) {
		try {
			PreparedStatement stmt = connection.prepareStatement("delete from cliente where idCliente=?");
			stmt.setLong(1, cliente.getIdCliente());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Cliente> listaCliente() {
		try {
			List<Cliente> clientes = new ArrayList<Cliente>();
			PreparedStatement stmt = this.connection.prepareStatement("select * from cliente");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				// criando o objeto Cliente
				Cliente cliente = new Cliente();
				cliente.setIdCliente(rs.getLong("idCliente"));
				cliente.setNome(rs.getString("nome"));
				cliente.setEmail(rs.getString("email"));
				cliente.setUsuario(rs.getString("usuario"));
				cliente.setSenha(rs.getString("senha"));
				cliente.setCpf(rs.getString("cpf"));

				// adicionando o objeto � lista
				clientes.add(cliente);
			}
			rs.close();
			stmt.close();
			return clientes;
		} catch (SQLException e) {
			throw new DAOException();
		}
	}

	public Cliente buscaCliente(String usuario) throws SQLException {
		String sql = "SELECT * FROM cliente WHERE usuario = ?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, usuario);
		Cliente cliente = null;
		ResultSet rs = stmt.executeQuery();

		if (rs.next()) {
			cliente = new Cliente(rs.getLong("idCliente"), rs.getString("nome"), rs.getString("email"),
					rs.getString("usuario"), rs.getString("senha"), rs.getString("cpf"));
		}
		return cliente;
	}

}
