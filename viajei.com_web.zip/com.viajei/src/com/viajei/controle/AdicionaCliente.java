package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.viajei.entidade.Cliente;
import com.viajei.persistencia.ClienteDao;

@WebServlet({ "/AdicionaCliente", "/Cadastrar", "/Salvar" })
public class AdicionaCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdicionaCliente() {
		super();

	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pegando os par�metros passados pelo formul�rio
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String usuario = request.getParameter("usuario");
		String senha = request.getParameter("senha");
		String cpf = request.getParameter("cpf");

		// Instanciando um Objeto do tipo Cliente
		Cliente cliente = new Cliente();
		cliente.setNome(nome);
		cliente.setEmail(email);
		cliente.setUsuario(usuario);
		cliente.setSenha(senha);
		cliente.setCpf(cpf);

		// Instanciando um Objeto do tipo ClienteDao
		try {
			ClienteDao dao = new ClienteDao();
			dao.adiciona(cliente);

		} catch (Exception e) {
			request.setAttribute("msg", "Erro ao cadastrar cliente");
			request.getRequestDispatcher("erro.jsp").forward(request, response);

		} finally {

			request.getSession().setAttribute("cliente", cliente);
			request.getSession().setAttribute("usuario", usuario);
			request.getRequestDispatcher("index.jsp").forward(request, response);

		}
	}

}
