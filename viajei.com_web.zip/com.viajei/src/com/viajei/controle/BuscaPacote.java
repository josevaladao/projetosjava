package com.viajei.controle;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Pacote;
import com.viajei.persistencia.PacoteDao;


@WebServlet("/BuscaPacote")
public class BuscaPacote extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BuscaPacote() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String destino = request.getParameter("destino");
			PacoteDao dao = new PacoteDao();
			List<Pacote> lista = dao.listaPorDestino(destino);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-warning text-center col-sm-offset-4 col-sm-4'>"
						+ "Nenhum Pacote encontrado, tente novamente!</div>");
				request.getRequestDispatcher("index.jsp").forward(request,response);
			}
			//request.setAttribute("destino", destino);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("pacotes.jsp").forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
