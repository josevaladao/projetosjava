package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Cliente;
import com.viajei.entidade.Login;
import com.viajei.persistencia.ClienteDao;

@WebServlet({ "/LogaCliente", "/Logar", "/Login" })
public class LogaCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LogaCliente() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String usuario = request.getParameter("usuario");
		String senha = request.getParameter("senha");
		String admin = "admin";

		if ((admin.equals(usuario) && admin.equals(senha)) && usuario.equals(admin)) {

			request.getSession().setAttribute("admin", admin);
			request.getSession().setAttribute("usuario", usuario);
			request.getRequestDispatcher("index.jsp").forward(request, response);

		} else {

			try {

				Login login = new ClienteDao().Login(usuario, senha);

				if (login != null) {
					ClienteDao dao = new ClienteDao();
					Cliente cliente = dao.buscaCliente(usuario);
					request.getSession().setAttribute("cliente", cliente);
					request.getSession().setAttribute("usuario", usuario);
					// System.out.println(usuario);
					response.sendRedirect("index.jsp");
				} else {
					request.setAttribute("msg", "<script> alert('Usuario n�o encontrado!'); </script>");
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			}

			catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "Erro" + e.getMessage());
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}
	}

}
