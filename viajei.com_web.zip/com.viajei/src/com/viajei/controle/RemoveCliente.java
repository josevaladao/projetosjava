package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Cliente;
import com.viajei.persistencia.ClienteDao;

@WebServlet("/RemoveCliente")
public class RemoveCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RemoveCliente() {
		super();

	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Pegando os par�metros passados pelo formul�rio
		Long idCliente = new Long(request.getParameter("idCliente"));

		// Instanciando um Objeto do tipo Cliente
		Cliente cliente = new Cliente();
		cliente.setIdCliente(idCliente);

		// Instanciando um Objeto do tipo ClienteDao
		try {
			ClienteDao dao = new ClienteDao();
			dao.remove(cliente);

		} catch (Exception e) {
			request.setAttribute("msg", "Erro ao remover cliente" + cliente.getNome());
			request.getRequestDispatcher("erro.jsp").forward(request, response);

		} finally {

			request.getSession().invalidate();
			response.sendRedirect("index.jsp");
		}
	}

}
