package com.viajei.controle;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Pacote;
import com.viajei.persistencia.PacoteDao;

@WebServlet({ "/BuscaPorID", "/edita.jsp" })
public class BuscaPorID extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BuscaPorID() {
		super();
		
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Integer idPacote = Integer.parseInt(request.getParameter("idPacote"));
			PacoteDao dao = new PacoteDao();
			List<Pacote> lista = dao.buscarPorId(idPacote);
			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-warning text-center col-sm-offset-4 col-sm-4'>"
						+ "Nenhum Pacote encontrado, tente novamente!</div>");
				request.getRequestDispatcher("WEB-INF/edita.jsp").forward(request, response);
			}
			// request.setAttribute("destino", destino);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("WEB-INF/edita.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
