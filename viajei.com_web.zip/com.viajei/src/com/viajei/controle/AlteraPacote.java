package com.viajei.controle;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Pacote;
import com.viajei.persistencia.PacoteDao;


@WebServlet({ "/AlteraPacote", "/SalvaEdicao" })
public class AlteraPacote extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AlteraPacote() {
        super();
        
    }

	
    protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

    	// Pegando os par�metros passados pelo formul�rio
    			String origem = request.getParameter("origem");
    			String destino = request.getParameter("destino");
    					
    			// Tratamento de datas
    			String dataEmTextoIda = request.getParameter("dataIda");
    			Calendar dataIda = null;
    			
    			String dataEmTextoVolta = request.getParameter("dataVolta");
    			Calendar dataVolta = null;
		
		
		// fazendo a convers�o da dataIda e dataVolta
				try {
					Date DataPadraoSQL = new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTextoIda);
					Date DataPadraoSQL2 = new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTextoVolta);
					
					dataIda = Calendar.getInstance();
					dataIda.setTime(DataPadraoSQL);
					
					dataVolta = Calendar.getInstance();
					dataVolta.setTime(DataPadraoSQL2);
				} catch (ParseException e) {
					System.out.println("Erro de convers�o da data");

					// debug
					
					System.out.println("data Venda:" + dataIda);
					System.out.println("data em texto:" + dataEmTextoIda);

					return;
				}
		
		
		String horario = request.getParameter("horario");
		String hospedagem = request.getParameter("hospedagem");
		String voo = request.getParameter("voo");
		String assento = request.getParameter("assento");
		String preco = request.getParameter("preco");
		String imagem = request.getParameter("imagem");
		Long idPacote = new Long(request.getParameter("idPacote"));

		// Instanciando um Objeto do tipo Pacote
		Pacote pacote = new Pacote();
		pacote.setOrigem(origem);
		pacote.setDestino(destino);
		pacote.setDataIda(dataIda);
		pacote.setDataVolta(dataVolta);
		pacote.setHorario(horario);
		pacote.setHospedagem(hospedagem);
		pacote.setVoo(voo);
		pacote.setAssento(assento);
		pacote.setPreco(preco);
		pacote.setImagem(imagem);
		pacote.setIdPacote((long)idPacote);

		// Instanciando um Objeto do tipo PacoteDao
		try {
			PacoteDao dao = new PacoteDao();
			dao.altera(pacote);

		} catch (Exception e) {
			request.setAttribute("msg", "Erro ao alterar pacote" + pacote.getOrigem() + " para " +pacote.getDestino());
			request.getRequestDispatcher("erro.jsp").forward(request, response);

		} finally {
			request.setAttribute("msg", "<h3 class='alert alert-succes'>Pacote " + pacote.getOrigem() + " para " +pacote.getDestino()+ " alterado com sucesso!!!</h3>");
			
			request.setAttribute("pacote", pacote);
			
			request.getRequestDispatcher("WEB-INF/admin.jsp").forward(request, response);

		}

	}

}
