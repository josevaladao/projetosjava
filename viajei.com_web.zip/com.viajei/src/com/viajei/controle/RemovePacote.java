package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viajei.entidade.Pacote;
import com.viajei.persistencia.PacoteDao;

@WebServlet("/RemovePacote")
public class RemovePacote extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RemovePacote() {
		super();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pegando os par�metros passados pelo formul�rio
		Long idPacote = new Long(request.getParameter("idPacote"));
		String origem = request.getParameter("origem");
		String destino = request.getParameter("destino");

		// Instanciando um Objeto do tipo Pacote
		Pacote pacote = new Pacote();
		pacote.setIdPacote(idPacote);

		// Instanciando um Objeto do tipo PacoteDao
		try {
			PacoteDao dao = new PacoteDao();
			dao.remove(pacote);

		} catch (Exception e) {
			request.setAttribute("msg", "<h3 class='alert alert-danger text-center'>Erro ao remover pacote" + origem
					+ " para " + destino + "</h3>");
			request.getRequestDispatcher("WEB-INF/admin.jsp").forward(request, response);

		} finally {
			request.setAttribute("msg", "<h3 class='alert alert-succes'>Pacote " + origem + " para " + destino
					+ " removido com Sucesso!!!</h3>");
			request.getRequestDispatcher("WEB-INF/admin.jsp").forward(request, response);

		}

	}

}
