package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet({"/DeslogaCliente", "/Sair", "/Logout"})
public class DeslogaCliente extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public DeslogaCliente() {
        super();        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Invalida sess�o e redireciona para login
        request.getSession().invalidate();
        response.sendRedirect("index.jsp");	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}