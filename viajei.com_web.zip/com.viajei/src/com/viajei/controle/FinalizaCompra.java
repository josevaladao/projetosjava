package com.viajei.controle;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

import com.viajei.entidade.Compra;
import com.viajei.persistencia.CompraDao;

@WebServlet("/FinalizaCompra")
public class FinalizaCompra extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FinalizaCompra() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("idCliente") == "") {

			request.setAttribute("msg", "<script>alert('Cadastre-se para comprar!');</script>");
			request.getRequestDispatcher("index.jsp").forward(request, response);

			return;
		}

		if (request.getParameter("usuario") != "") {

			// buscando os par�metros no request (enviados pelo formul�rio HTML)
			Long idPacote = Long.parseLong(request.getParameter("idPacote"));
			Long idCliente = Long.parseLong(request.getParameter("idCliente"));
			String emailCliente = request.getParameter("email");
			String nome = request.getParameter("nome");

			String dataEmTexto = request.getParameter("dataVenda");
			Calendar dataVenda = null;

			// fazendo a convers�o da data
			try {
				Date DataPadraoSQL = new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTexto);
				dataVenda = Calendar.getInstance();
				dataVenda.setTime(DataPadraoSQL);
			} catch (ParseException e) {
				System.out.println("Erro de convers�o da data");

				// debug
				System.out.println("id Pacote:" + idPacote);
				System.out.println("id Cliente:" + idCliente);
				System.out.println("data Venda:" + dataVenda);
				System.out.println("data em texto:" + dataEmTexto);

				return;
			}

			// monta um objeto compra
			Compra compra = new Compra();
			compra.setDataVenda(dataVenda);
			compra.setIdPacote(idPacote);
			compra.setIdCliente(idCliente);

			// Instanciando um Objeto do tipo CompraDao
			try {
				CompraDao dao = new CompraDao();
				dao.salva(compra);

			} catch (Exception e) {
				request.setAttribute("msg", "Erro ao salvar compra");
				request.getRequestDispatcher("erro.jsp").forward(request, response);

			} finally {
				// envia email com voucher

				SimpleEmail email = new SimpleEmail();
				email.setSSLOnConnect(true);
				email.setHostName("smtp.gmail.com");
				email.setSslSmtpPort("465");
				email.setAuthenticator(new DefaultAuthenticator("viajei.confirmacao@gmail.com", "Senac!@2017"));
				try {
					email.setFrom("leandrovitorio.ti@gmail.com");
					email.setDebug(false); // habilite para debugar
					email.setSubject("Confirma��o de compra - Viajei.com");
					email.setMsg("Parab�ns " + nome + "! Seu voucher �: " + idPacote + idCliente);
					email.addTo(emailCliente);
					email.send();

				} catch (EmailException e) {
					e.printStackTrace();
				}

				request.setAttribute("msg",
						"<script>alert('Compra realizada com sucesso!\\nO Voucher foi enviado para o e-mail: "
								+ emailCliente + "');</script>");
				request.getRequestDispatcher("pacotes.jsp").forward(request, response);

			}

		} else {
			request.setAttribute("msg", "<script>alert('Cadastre-se para comprar!');</script>");
			request.getRequestDispatcher("index.jsp").forward(request, response);

		}
	}
}
