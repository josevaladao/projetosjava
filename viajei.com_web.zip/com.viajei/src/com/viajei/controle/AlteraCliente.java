package com.viajei.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.viajei.entidade.Cliente;
import com.viajei.persistencia.ClienteDao;

@WebServlet("/AlteraCliente")
public class AlteraCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AlteraCliente() {
		super();

	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pegando os par�metros passados pelo formul�rio
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String usuario = request.getParameter("usuario");
		String senha = request.getParameter("senha");
		String cpf = request.getParameter("cpf");
		Long idCliente = new Long(request.getParameter("idCliente"));

		// Instanciando um Objeto do tipo Cliente
		Cliente cliente = new Cliente();
		cliente.setNome(nome);
		cliente.setEmail(email);
		cliente.setUsuario(usuario);
		cliente.setSenha(senha);
		cliente.setCpf(cpf);
		cliente.setIdCliente((long) idCliente);

		// Instanciando um Objeto do tipo PacoteDao
		try {
			ClienteDao dao = new ClienteDao();
			dao.altera(cliente);

		} catch (Exception e) {
			request.setAttribute("msg", "Erro ao alterar cliente" + cliente.getNome());
			request.getRequestDispatcher("erro.jsp").forward(request, response);

		} finally {
			request.setAttribute("msg", "Pacote " + cliente.getNome() + " alterado com Sucesso!!!");
			// request.getRequestDispatcher("admin.jsp").forward(request,
			// response);

		}
	}

}
