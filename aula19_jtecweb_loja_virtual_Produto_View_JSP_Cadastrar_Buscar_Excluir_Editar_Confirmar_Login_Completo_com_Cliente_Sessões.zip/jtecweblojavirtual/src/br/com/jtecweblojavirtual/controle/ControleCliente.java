package br.com.jtecweblojavirtual.controle;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.jtecweblojavirtual.entidade.Admin;
import br.com.jtecweblojavirtual.entidade.Cliente;
import br.com.jtecweblojavirtual.entidade.Login;
import br.com.jtecweblojavirtual.persistencia.AdminDao;
import br.com.jtecweblojavirtual.persistencia.ClienteDao;

@WebServlet(name = "/ControleCliente", urlPatterns = { "/cadastrarCliente.html", "/editarCliente.html",
		"/excluirCliente.html", "/buscarCliente.html", "/confirmarCliente.html","/logarCliente.html",
		"/sairCliente.html","/sairAdmin.html" })
public class ControleCliente extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public ControleCliente() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String url = request.getServletPath();

			if (url.equalsIgnoreCase("/cadastrarCliente.html")) {
				cadastrar(request, response);
			} else if (url.equalsIgnoreCase("/editarCliente.html")) {
				editar(request, response);
			} else if (url.equalsIgnoreCase("/excluirCliente.html")) {
				excluir(request, response);
			} else if (url.equalsIgnoreCase("/buscarCliente.html")) {
				buscar(request, response);
			} else if (url.equalsIgnoreCase("/confirmarCliente.html")) {
				confirmar(request, response);
			} else if (url.equalsIgnoreCase("/logarCliente.html")) {
				logar(request, response);
			} else if (url.equalsIgnoreCase("/sairCliente.html")) {
				sair(request, response);
			} else if (url.equalsIgnoreCase("/sairAdmin.html")) {
				sairAdmin(request, response);
			} else {
				throw new Exception("URL Inv�lida!!!");
			}
		} catch (Exception e) {
			response.sendRedirect("index.jsp");
			e.printStackTrace();
		}

	}

	protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Pegando os par�metros passados pelo formul�rio
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		String cpf = request.getParameter("cpf");

		// Instanciando um Objeto do tipo Cliente
		Cliente cliente = new Cliente();
		cliente.setNome(nome);
		cliente.setEmail(email);
		cliente.setLogin(login);
		cliente.setSenha(senha);
		cliente.setCpf(cpf);// Instanciando um Objeto do tipo ClienteDao
		try {
			ClienteDao dao = new ClienteDao();
			dao.adicionar(cliente);
			request.getSession().setAttribute("cliente", cliente);
			request.getSession().setAttribute("login", login);	
			request.setAttribute("msg", "<div class='alert alert-success'>Cliente Cadastrado!</div>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Cliente n�o Cadastrado!</div>!!!");
		} finally {		
			request.getRequestDispatcher("sessaoCliente.jsp").forward(request, response);
		}
	}

	public void editar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// Capturando o Id do Cliente vindo do formul�rio
			Integer idCliente = new Integer(request.getParameter("id"));
			Cliente cli = new ClienteDao().buscarPorIdCliente(idCliente);

			if (cli == null) {
				request.setAttribute("msg", "<div class='alert alert-info'>Cliente n�o encontrado!</div>");
				request.getRequestDispatcher("buscaCliente.jsp").forward(request, response);
			} else {
				request.setAttribute("cli", cli);
				request.getRequestDispatcher("editaCliente.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: " + e.getMessage() + "</div>");
			request.getRequestDispatcher("buscaCliente.jsp").forward(request, response);
		}
	}

	protected void excluir(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Pegando os par�metros passados pelo formul�rio
		Long idCliente = new Long(request.getParameter("id"));

		// Instanciando um Objeto do tipo Cliente
		Cliente cliente = new Cliente();
		cliente.setIdCliente(idCliente);

		// Instanciando um Objeto do tipo ClienteDao
		try {
			ClienteDao dao = new ClienteDao();
			dao.excluir(cliente);

		} catch (Exception e) {
			request.setAttribute("msg", "Erro ao excluir cliente" + cliente.getNome());
			request.getRequestDispatcher("erro.jsp").forward(request, response);

		} finally {
			//request.getSession().invalidate();
			response.sendRedirect("buscaCliente.jsp");
		}
	}

	public void buscar(HttpServletRequest request, HttpServletResponse response) {
		try {
			String nomeCliente = request.getParameter("nome");
			ClienteDao pd = new ClienteDao();

			List<Cliente> lista = pd.listarCliente(nomeCliente);

			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>Nenhum Cliente Encontrado!</div>");
			}
			request.setAttribute("nomeCliente", nomeCliente);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscaCliente.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void confirmar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			// Pegando os par�metros passados pelo formul�rio
			String nome = request.getParameter("nome");
			String email = request.getParameter("email");
			String login = request.getParameter("login");
			String senha = request.getParameter("senha");
			String cpf = request.getParameter("cpf");
			String idCliente = request.getParameter("id");

			// Instanciando um Objeto do tipo Cliente
			Cliente cliente = new Cliente();
			cliente.setNome(nome);
			cliente.setEmail(email);
			cliente.setLogin(login);
			cliente.setSenha(senha);
			cliente.setCpf(cpf);// Instanciando um Objeto do tipo ClienteDao
			cliente.setIdCliente(new Long(idCliente));

			// Gravando os dados no Banco de Dados

			ClienteDao pd = new ClienteDao();
			pd.editar(cliente);
			request.getSession().setAttribute("cliente", cliente);
			request.getSession().setAttribute("login", login);	
			request.setAttribute("msg", "<div class='alert alert-success'>Cliente atualizado!</div>");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Cliente n�o Atualizado!</div>");
		} finally {
			request.getRequestDispatcher("buscaCliente.jsp").forward(request, response);
		}

	}

	protected void logar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, ClassNotFoundException, SQLException {
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		//String admin = "admin";
		Cliente cliente = new ClienteDao().login(login, senha);
		Admin admin = new AdminDao().consultarLoginSenha(login, senha);

		if (admin != null) {

			request.getSession().setAttribute("admin", admin);
			request.getSession().setAttribute("login", login);
			request.getRequestDispatcher("sessaoAdmin.jsp").forward(request, response);
		} else {

			try {

				if (cliente != null) {					
					
					request.getSession().setAttribute("cliente", cliente);
					request.getSession().setAttribute("login", login);					
					response.sendRedirect("sessaoCliente.jsp");
				} else {
					request.setAttribute("msg", "<div class='alert alert-danger'>Login n�o Encontrado!</div>");
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
			}

			catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "Erro" + e.getMessage());
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}
	}

	protected void sair(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Invalidando a sess�o e deslogar do sistema
		request.getSession().invalidate();
		response.sendRedirect("index.jsp");
	}
	protected void sairAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Invalidando a sess�o e deslogar do sistema
		request.getSession().invalidate();
		response.sendRedirect("index.jsp");
	}

}
